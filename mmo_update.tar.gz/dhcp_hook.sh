#!/bin/sh
# /etc/mmo-proxy/bin/dhcp_hook.sh
ACTION="$1"
MAC="$2"
IP="$3"
HOST="$4"

[ -z "$MAC" ] && exit 0

CONF_DIR="/etc/mmo-proxy"
CORE="$CONF_DIR/bin/mmo-core"

# Cache IP persistently for quick lookup on reboots
if [ -n "$IP" ]; then
    mkdir -p "$CONF_DIR/config"
    CACHE_FILE="$CONF_DIR/config/device_ips.json"
    [ ! -f "$CACHE_FILE" ] && echo '{}' > "$CACHE_FILE"
    jq --arg m "$MAC" --arg ip "$IP" '.[$m] = $ip' "$CACHE_FILE" > "$CACHE_FILE.tmp" 2>/dev/null && mv "$CACHE_FILE.tmp" "$CACHE_FILE"
fi

# Trigger on newly connected device ("add") or renewed lease ("old")
if [ "$ACTION" = "add" -o "$ACTION" = "old" ]; then
    case "$IP" in
        192.168.99.*)
            # Tự động gán ngay thiết bị vào luồng VPN riêng biệt khi bắt Wi-Fi ExpressVPN
            [ -x /www/api/expressvpn ] && /www/api/expressvpn sync "$IP" >/dev/null 2>&1 &
            ;;
        *)
            if [ -x "$CORE" ]; then
                "$CORE" fast-assign "$MAC" "$IP" "$HOST" >/dev/null 2>&1
            fi
            ;;
    esac
fi

# Trigger on disconnected device ("del") -> Bỏ cấp proxy và xoá thiết bị ngay lập tức
if [ "$ACTION" = "del" ]; then
    case "$IP" in
        192.168.99.*)
            ip rule del from "$IP" priority 5195 2>/dev/null || true
            conntrack -D -s "$IP" >/dev/null 2>&1 || true
            ;;
        *)
            if [ -x "$CORE" ]; then
                "$CORE" on-offline "$MAC" >/dev/null 2>&1 &
            fi
            ;;
    esac
fi

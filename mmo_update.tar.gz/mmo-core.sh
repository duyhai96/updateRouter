#!/bin/sh
# /etc/mmo-proxy/bin/mmo-core

CONF_DIR="/etc/mmo-proxy"
export ENABLE_DEPRECATED_WIREGUARD_OUTBOUND=true
CONFIG_PROXIES="$CONF_DIR/config/proxies.json"
CONFIG_VPN="$CONF_DIR/config/vpn.json"
CONFIG_MAPPINGS="$CONF_DIR/config/mappings.json"
CONFIG_SETTINGS="$CONF_DIR/config/settings.json"
SINGBOX_CONF="$CONF_DIR/singbox/config.json"
NFT_RULES="$CONF_DIR/firewall/rules.nft"

generate_singbox() {
    [ -f "$CONFIG_VPN" ] || echo '{"vpns":[]}' > "$CONFIG_VPN"
    jq -n \
      --slurpfile proxies "$CONFIG_PROXIES" \
      --slurpfile vpns "$CONFIG_VPN" \
      --slurpfile mappings "$CONFIG_MAPPINGS" \
      --slurpfile settings "$CONFIG_SETTINGS" '
      ($settings[0].tproxy_base_port // 15000) as $base_port |
      ($proxies[0].proxies // []) as $plist |
      ($vpns[0].vpns // []) as $vlist |
      ($settings[0].direct_wan_devices // []) as $direct_macs |
      [ ($mappings[0].mappings // [])[] | select(.mac as $m | ($direct_macs | index($m)) == null) ] as $mlist |
       ($settings[0].domain_routing.mode // "all_proxy") as $routing_mode |
       ($settings[0].domain_routing.proxy_domains // []) as $proxy_domain_list |
       ($settings[0].domain_routing.bypass_list // []) as $bypass_list |
      ($settings[0].domain_routing.block_list // []) as $block_list |
      (if $settings[0].security.disable_udp == false then false else true end) as $disable_udp |
      (if $settings[0].security.webrtc_shield == false then false else true end) as $webrtc_shield |
      ($settings[0].security.webrtc_mode // "block") as $webrtc_mode |
      (if $settings[0].security.disable_ipv6_leak == false then false else true end) as $disable_ipv6 |

      # Pure jq function to check if string is IP without Oniguruma regex
      def is_ip:
        if contains(":") then
          true
        else
          (split("/")[0] | split(".") | (length == 4 and (.[0] | try tonumber catch null != null)))
        end;

      def lstrip_star:
        if startswith("*.") then .[2:]
        elif startswith("*") then .[1:]
        elif startswith(".") then .[1:]
        else .
        end;

      # Extract domains vs IPs for proxy only (clean leading *. or * if present)
      [ $proxy_domain_list[] | select(is_ip | not) | lstrip_star ] as $proxy_domains |
      [ $proxy_domain_list[] | select(is_ip) ] as $proxy_ips |

      # Extract domains vs IPs for bypass (clean leading *. or * if present)
      [ $bypass_list[] | select(is_ip | not) | lstrip_star ] as $bypass_domains |
      [ $bypass_list[] | select(is_ip) ] as $bypass_ips |

      # Extract domains vs IPs for block (clean leading *. or * if present)
      [ $block_list[] | select(is_ip | not) | lstrip_star ] as $block_domains |
      [ $block_list[] | select(is_ip) ] as $block_ips |

      # DNS servers
      [
        {
          tag: "dns_direct",
          type: "udp",
          server: "1.1.1.1"
        }
      ] + [
        $mlist[] |
        . as $m |
        ( ($vlist[] | select(.name == $m.proxy and .enabled != false)) ) as $vpn_target |
        {
          tag: ("dns_" + $m.mac),
          type: (if $vpn_target != null then "udp" else "tcp" end),
          server: (if $vpn_target != null and $vpn_target.dns and $vpn_target.dns != "" then ($vpn_target.dns | split(",")[0] | gsub(" "; "")) else "8.8.8.8" end),
          detour: $m.proxy
        }
      ] as $dns_servers |

      # DNS rules (In proxy_only mode, only proxy_domains query proxy DNS; in all_proxy mode, bypass_domains query dns_direct)
      (if $routing_mode == "proxy_only" then
        (if ($proxy_domains | length) > 0 then
          [
            $mlist[] |
            {
              inbound: [("tproxy_" + .mac)],
              domain_suffix: $proxy_domains,
              server: ("dns_" + .mac)
            }
          ]
        else [] end) +
        [ { server: "dns_direct" } ]
      else
        (if ($bypass_domains | length) > 0 then [ { domain_suffix: $bypass_domains, server: "dns_direct" } ] else [] end) +
        [
          $mlist[] |
          {
            inbound: [("tproxy_" + .mac)],
            server: ("dns_" + .mac)
          }
        ]
      end) as $dns_rules |

      # Inbounds
      [range(0; $mlist | length)] as $indices |
      [
        $indices[] |
        {
          type: "tproxy",
          tag: ("tproxy_" + $mlist[.].mac),
          listen: "::",
          listen_port: ($base_port + . + 1),
          sniff: true,
          sniff_override_destination: true
        }
      ] as $inbounds |

      # Outbounds
      [
        { type: "direct", tag: "direct" },
        { type: "block", tag: "block" }
      ] + [
        $plist[] | select(.enabled != false) |
        if .type == "http" then
          {
            type: "http",
            tag: .name,
            server: .host,
            server_port: (.port | tonumber)
          } + (if .user and .user != "" then { username: .user, password: (.pass // "") } else {} end)
        elif .type == "shadowsocks" then
          {
            type: "shadowsocks",
            tag: .name,
            server: .host,
            server_port: (.port | tonumber),
            method: (.method // "aes-256-gcm"),
            password: (.pass // "")
          }
        else
          {
            type: "socks",
            tag: .name,
            server: .host,
            server_port: (.port | tonumber)
          } + (if .user and .user != "" then { username: .user, password: (.pass // "") } else {} end)
        end
      ] + [
        $vlist[] | select(.enabled != false) |
        {
          type: "wireguard",
          tag: .name,
          server: .server,
          server_port: (.server_port | tonumber),
          local_address: (if (.local_address | type) == "array" then .local_address else [(.local_address // "10.0.0.2/32")] end),
          private_key: .private_key,
          peer_public_key: .peer_public_key
        } + (if .pre_shared_key and .pre_shared_key != "" then { pre_shared_key: .pre_shared_key } else {} end)
          + (if .reserved and (.reserved | length) > 0 then { reserved: .reserved } else {} end)
          + (if .mtu and (.mtu | tonumber) > 0 then { mtu: (.mtu | tonumber) } else {} end)
      ] as $outbounds |

      # Build route rules
      (
        # 1. DNS hijack
        [ { port: 53, action: "hijack-dns" } ] +
        # 2. WebRTC Shield: QUIC (UDP 443) & WebRTC STUN/TURN (3478, 5349, 19302, 19305)
        (if $webrtc_shield then
          (if $webrtc_mode == "sync" then
            # Sync mode: Reject QUIC 443 to enforce TCP proxying, but allow STUN ports (3478, 5349, 19302, 19305)
            # to be routed through each device assigned proxy tunnel so WebRTC reflects the Proxy IP
            [ { network: "udp", port: [443], action: "reject" } ]
          else
            # Block mode (RFC 8828): Reject all STUN and QUIC ports
            [ { network: "udp", port: [443, 3478, 5349, 19302, 19305], action: "reject" } ]
          end)
        else [] end) +
        # 3. Block list
        (if ($block_domains | length) > 0 then [ { domain_suffix: $block_domains, outbound: "block" } ] else [] end) +
        (if ($block_ips | length) > 0 then [ { ip_cidr: $block_ips, outbound: "block" } ] else [] end) +
        # 4. Mode-specific routing:
        (if $routing_mode == "proxy_only" then
          # Proxy only matching domains/IPs for each mapped device:
          [
            $mlist[] |
            . as $dev |
            (
              (if ($proxy_domains | length) > 0 then [ { inbound: [("tproxy_" + $dev.mac)], domain_suffix: $proxy_domains, outbound: $dev.proxy } ] else [] end) +
              (if ($proxy_ips | length) > 0 then [ { inbound: [("tproxy_" + $dev.mac)], ip_cidr: $proxy_ips, outbound: $dev.proxy } ] else [] end)
            )[]
          ] +
          # Any other traffic from mapped devices goes direct:
          [ { outbound: "direct" } ]
        else
          # All proxy mode (Default): Bypass list goes direct
          (if ($bypass_domains | length) > 0 then [ { domain_suffix: $bypass_domains, outbound: "direct" } ] else [] end) +
          (if ($bypass_ips | length) > 0 then [ { ip_cidr: $bypass_ips, outbound: "direct" } ] else [] end) +
          # Inbound to proxy mappings
          [
            $mlist[] |
            {
              inbound: [("tproxy_" + .mac)],
              outbound: .proxy
            }
          ]
        end) +
        # 5. Disable UDP if proxy has no UDP
        (if $disable_udp then [ { network: "udp", action: "reject" } ] else [] end)
      ) as $rules |

      {
        log: {
          level: "warn",
          timestamp: true
        },
        dns: {
          servers: $dns_servers,
          rules: $dns_rules,
          final: "dns_direct",
          strategy: (if $disable_ipv6 then "ipv4_only" else "prefer_ipv4" end)
        },
        inbounds: $inbounds,
        outbounds: $outbounds,
        route: {
          default_domain_resolver: "dns_direct",
          rules: $rules,
          auto_detect_interface: true
        }
      }
    ' > "$SINGBOX_CONF.tmp"

    mv "$SINGBOX_CONF.tmp" "$SINGBOX_CONF"
}

generate_firewall() {
    cat << 'NFT_HEADER' > "$NFT_RULES.tmp"
table inet mmo_proxy {
    chain prerouting {
        type filter hook prerouting priority mangle; policy accept;

        # DHCP bypass
        udp dport { 67, 68 } return

        # Local router management bypass (SSH, LuCI WebUI, MMO WebUI)
        ip daddr 192.168.88.1 tcp dport { 22, 80, 443, 8888 } return

NFT_HEADER

    # Whitelist Direct WAN Devices (Exception devices like admin PC)
    DIRECT_MACS=$(jq -r '.direct_wan_devices // [] | .[]' "$CONFIG_SETTINGS" 2>/dev/null)
    DIRECT_IPS=""
    for dmac in $DIRECT_MACS; do
        dip=$(grep -i "$dmac" /tmp/dhcp.leases 2>/dev/null | awk '{print $3}' | head -n1)
        [ -z "$dip" ] && dip=$(grep -i "$dmac" /proc/net/arp 2>/dev/null | awk '{print $1}' | head -n1)
        [ -z "$dip" ] && dip=$(uci show dhcp 2>/dev/null | grep -i "$dmac" -B1 | grep "\.ip=" | head -n1 | cut -d"'" -f2)
        [ -z "$dip" ] && [ -f "$CONF_DIR/config/device_ips.json" ] && dip=$(jq -r --arg mac "$dmac" '.[$mac] // empty' "$CONF_DIR/config/device_ips.json" 2>/dev/null)
        if [ -n "$dip" ]; then
            DIRECT_IPS="$DIRECT_IPS $dip"
        fi
    done

    # 1. Direct WAN bypass by MAC address (Permanent link-layer bypass, works instantly after boot before DHCP leases)
    if [ -n "$DIRECT_MACS" ]; then
        DMAC_LIST=$(echo $DIRECT_MACS | sed 's/ /, /g')
        echo "        # Direct WAN devices bypass by MAC (Whitelist)" >> "$NFT_RULES.tmp"
        echo "        ether saddr { $DMAC_LIST } meta mark set 0x200 return" >> "$NFT_RULES.tmp"
    fi

    # 2. Direct WAN bypass by IP address
    if [ -n "$DIRECT_IPS" ]; then
        DIP_LIST=$(echo $DIRECT_IPS | sed 's/ /, /g')
        echo "        # Direct WAN devices bypass by IP (Whitelist)" >> "$NFT_RULES.tmp"
        echo "        ip saddr { $DIP_LIST } meta mark set 0x200 return" >> "$NFT_RULES.tmp"
    fi

    cat << 'NFT_LOCAL' >> "$NFT_RULES.tmp"
        # Private LAN bypass (except DNS port 53 which gets hijacked to proxy)
        meta l4proto { tcp, udp } th dport != 53 ip daddr { 127.0.0.0/8, 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 224.0.0.0/4, 255.255.255.255 } return

NFT_LOCAL

    # Client Isolation: Block client-to-client traffic except to Whitelist devices
    CLIENT_ISOLATION=$(jq -r '.security.client_isolation // false' "$CONFIG_SETTINGS")
    if [ "$CLIENT_ISOLATION" = "true" ]; then
        if [ -n "$DIRECT_MACS" ]; then
            DMAC_LIST=$(echo $DIRECT_MACS | sed 's/ /, /g')
            echo "        # Client Isolation: Allow traffic to Whitelist devices by MAC" >> "$NFT_RULES.tmp"
            echo "        ether daddr { $DMAC_LIST } accept" >> "$NFT_RULES.tmp"
        fi
        if [ -n "$DIRECT_IPS" ]; then
            DIP_LIST=$(echo $DIRECT_IPS | sed 's/ /, /g')
            # Allow clients to talk to Whitelist PC, but drop traffic between non-whitelist clients
            echo "        # Client Isolation: Drop cross-client LAN traffic" >> "$NFT_RULES.tmp"
            echo "        ip daddr 192.168.88.0/24 ip daddr != { 192.168.88.1, $DIP_LIST } drop" >> "$NFT_RULES.tmp"
        else
            echo "        # Client Isolation: Drop cross-client LAN traffic" >> "$NFT_RULES.tmp"
            echo "        ip daddr 192.168.88.0/24 ip daddr != 192.168.88.1 drop" >> "$NFT_RULES.tmp"
        fi
    fi

    # TPROXY rules for mapped clients (excluding Direct WAN whitelist devices)
    BASE_PORT=$(jq -r '.tproxy_base_port // 15000' "$CONFIG_SETTINGS")
    idx=1
    MAPPED_IPS=""
    for ip in $(jq -r '.mappings[] | .ip' "$CONFIG_MAPPINGS"); do
        # Check if this IP is in DIRECT_IPS
        IS_DIR=0
        for dip in $DIRECT_IPS; do
            [ "$ip" = "$dip" ] && IS_DIR=1 && break
        done
        if [ "$IS_DIR" -eq 0 ]; then
            PORT=$((BASE_PORT + idx))
            echo "        ip saddr $ip meta l4proto { tcp, udp } tproxy ip to :$PORT meta mark set 0x100 accept" >> "$NFT_RULES.tmp"
            MAPPED_IPS="$MAPPED_IPS $ip"
            idx=$((idx + 1))
        fi
    done

    cat << 'NFT_MID' >> "$NFT_RULES.tmp"
    }

    chain forward {
        type filter hook forward priority filter; policy accept;

        # Established & related connections always pass
        ct state { established, related } accept

        # Direct WAN whitelist devices marked 0x200 in prerouting (by MAC or IP)
        meta mark 0x200 counter accept
NFT_MID

    # Direct WAN devices: explicitly allow forwarding by IP
    if [ -n "$DIRECT_IPS" ]; then
        DIP_LIST=$(echo $DIRECT_IPS | sed 's/ /, /g')
        echo "        # Direct WAN devices: explicitly allow forwarding by IP" >> "$NFT_RULES.tmp"
        echo "        ip saddr { $DIP_LIST } counter accept" >> "$NFT_RULES.tmp"
    fi

    ROUTING_MODE=$(jq -r '.domain_routing.mode // "all_proxy"' "$CONFIG_SETTINGS")
    KILL_SWITCH=$(jq -r 'if .security.kill_switch == false then "false" else "true" end' "$CONFIG_SETTINGS")
    if [ "$KILL_SWITCH" = "true" ] && [ "$ROUTING_MODE" != "proxy_only" ] && [ -n "$MAPPED_IPS" ]; then
        IP_LIST=$(echo $MAPPED_IPS | sed 's/ /, /g')
        echo "        # Kill switch: Block direct WAN forward for mapped clients" >> "$NFT_RULES.tmp"
        echo "        ip saddr { $IP_LIST } oifname \"wan*\" counter drop" >> "$NFT_RULES.tmp"
    fi

    # WebRTC Leak Shield in Kernel
    WEBRTC_SHIELD=$(jq -r 'if .security.webrtc_shield == false then "false" else "true" end' "$CONFIG_SETTINGS")
    WEBRTC_MODE=$(jq -r '.security.webrtc_mode // "block"' "$CONFIG_SETTINGS")
    if [ "$WEBRTC_SHIELD" = "true" ]; then
        if [ "$WEBRTC_MODE" = "sync" ]; then
            echo "        # WebRTC Sync mode: Drop direct WAN QUIC, allow STUN through Proxy tunnel" >> "$NFT_RULES.tmp"
            echo "        udp dport 443 counter drop" >> "$NFT_RULES.tmp"
        else
            echo "        # WebRTC Shield (RFC 8828): Block STUN and QUIC egress to prevent identity leaks" >> "$NFT_RULES.tmp"
            echo "        udp dport { 443, 3478, 5349, 19302, 19305 } counter drop" >> "$NFT_RULES.tmp"
        fi
    fi

    # Block unmapped devices only if strict fail_closed explicitly enabled in UI
    STRICT_FAIL_CLOSED=$(jq -r '.security.fail_closed // false' "$CONFIG_SETTINGS")
    if [ "$STRICT_FAIL_CLOSED" = "true" ]; then
        if [ -n "$DIRECT_IPS" ]; then
            DIP_LIST=$(echo $DIRECT_IPS | sed 's/ /, /g')
            echo "        # Fail-closed: Block all unassigned devices except Direct WAN whitelist" >> "$NFT_RULES.tmp"
            echo "        ip saddr != { 192.168.88.1, $DIP_LIST } oifname \"wan*\" counter drop" >> "$NFT_RULES.tmp"
        else
            echo "        # Fail-closed: Block all unassigned devices except router itself" >> "$NFT_RULES.tmp"
            echo "        ip saddr != 192.168.88.1 oifname \"wan*\" counter drop" >> "$NFT_RULES.tmp"
        fi
    fi

    DISABLE_IPV6=$(jq -r 'if .security.disable_ipv6_leak == false then "false" else "true" end' "$CONFIG_SETTINGS")
    if [ "$DISABLE_IPV6" = "true" ]; then
        echo "        # IPv6 leak protection" >> "$NFT_RULES.tmp"
        echo "        meta nfproto ipv6 oifname \"wan*\" counter drop" >> "$NFT_RULES.tmp"
    fi

    # DPI Evasion & Stealth: Clamp TCP MSS to 1400 bytes to prevent fragmentation and DPI fingerprinting
    DPI_STEALTH=$(jq -r 'if .security.dpi_stealth == false then "false" else "true" end' "$CONFIG_SETTINGS")
    if [ "$DPI_STEALTH" = "true" ]; then
        echo "        # DPI Evasion: Clamp TCP MSS to 1400" >> "$NFT_RULES.tmp"
        echo "        tcp flags syn tcp option maxseg size set 1400" >> "$NFT_RULES.tmp"
    fi

    cat << 'NFT_FOOTER' >> "$NFT_RULES.tmp"
    }
}
NFT_FOOTER

    mv "$NFT_RULES.tmp" "$NFT_RULES"
}

check_auto_proxy() {
    RESET_MODE="${1:-0}"
    AUTO_ENABLE=$(jq -r '.auto_proxy.enable // false' "$CONFIG_SETTINGS")
    [ "$AUTO_ENABLE" != "true" ] && return 0

    PROXY_COUNT=$(jq '.auto_proxy.proxy_list | length' "$CONFIG_SETTINGS" 2>/dev/null || echo 0)
    [ "$PROXY_COUNT" -le 0 ] && return 0

    ALLOW_DUP=$(jq -r '.auto_proxy.allow_duplicate // true' "$CONFIG_SETTINGS")
    DIRECT_MACS=$(jq -r '.direct_wan_devices // [] | .[]' "$CONFIG_SETTINGS" 2>/dev/null)

    # Ensure mappings and proxies files are valid JSON
    [ ! -s "$CONFIG_MAPPINGS" ] || ! jq -e . "$CONFIG_MAPPINGS" >/dev/null 2>&1 && echo '{"mappings":[]}' > "$CONFIG_MAPPINGS"
    [ ! -s "$CONFIG_PROXIES" ] || ! jq -e . "$CONFIG_PROXIES" >/dev/null 2>&1 && echo '{"proxies":[]}' > "$CONFIG_PROXIES"

    # If reset mode: clear existing proxy mappings for non-whitelist devices to re-distribute freshly
    if [ "$RESET_MODE" = "reset" ] || [ "$RESET_MODE" = "1" ]; then
        echo "[*] Auto-Proxy: Resetting existing mappings for auto distribution..."
        jq --argjson direct "$(jq '.direct_wan_devices // []' "$CONFIG_SETTINGS" 2>/dev/null || echo '[]')" '
          .mappings = [((.mappings // [])[]) | select(.mac as $m | ($direct | index($m)) != null)]
        ' "$CONFIG_MAPPINGS" > "$CONFIG_MAPPINGS.tmp" && [ -s "$CONFIG_MAPPINGS.tmp" ] && mv "$CONFIG_MAPPINGS.tmp" "$CONFIG_MAPPINGS"
    fi

    # Pre-parse and register all proxies in auto_proxy.proxy_list into proxies.json
    idx=0
    while [ "$idx" -lt "$PROXY_COUNT" ]; do
        RAW_PROXY=$(jq -r --argjson i "$idx" '.auto_proxy.proxy_list[$i]' "$CONFIG_SETTINGS")
        if [ -n "$RAW_PROXY" ] && [ "$RAW_PROXY" != "null" ]; then
            PNAME="Auto_$(echo "$RAW_PROXY" | md5sum | cut -c1-6)"
            HOST=$(echo "$RAW_PROXY" | sed -e 's|^socks5://||' -e 's|^http://||' | cut -d':' -f1)
            PORT=$(echo "$RAW_PROXY" | sed -e 's|^socks5://||' -e 's|^http://||' | cut -d':' -f2)
            USER=$(echo "$RAW_PROXY" | sed -e 's|^socks5://||' -e 's|^http://||' | cut -d':' -f3)
            PASS=$(echo "$RAW_PROXY" | sed -e 's|^socks5://||' -e 's|^http://||' | cut -d':' -f4)

            if [ -n "$HOST" ] && [ -n "$PORT" ]; then
                jq --arg name "$PNAME" --arg host "$HOST" --arg port "$PORT" --arg user "$USER" --arg pass "$PASS" '
                  .proxies = [((.proxies // [])[]) | select(.name != $name)] + [{name: $name, type: "socks5", host: $host, port: ($port|tonumber), user: ($user // ""), pass: ($pass // ""), enabled: true}]
                ' "$CONFIG_PROXIES" > "$CONFIG_PROXIES.tmp" && [ -s "$CONFIG_PROXIES.tmp" ] && mv "$CONFIG_PROXIES.tmp" "$CONFIG_PROXIES"
            fi
        fi
        idx=$((idx + 1))
    done

    NEED_APPLY=0
    # Determine starting p_idx from number of currently-mapped non-whitelist devices
    CURRENT_MAPPED_COUNT=$(jq --argjson direct "$(jq '.direct_wan_devices // []' "$CONFIG_SETTINGS" 2>/dev/null || echo '[]')" '
      [((.mappings // [])[]) | select(.mac as $m | ($direct | index($m)) == null and .proxy != "DIRECT")] | length
    ' "$CONFIG_MAPPINGS" 2>/dev/null)
    [ -z "$CURRENT_MAPPED_COUNT" ] || [ "$CURRENT_MAPPED_COUNT" = "null" ] && CURRENT_MAPPED_COUNT=0

    p_idx="$CURRENT_MAPPED_COUNT"

    # Scan active leases
    if [ -f /tmp/dhcp.leases ]; then
        while read ts mac ip host client_id; do
            [ -z "$mac" ] && continue

            # Check if this MAC is in direct whitelist
            IS_DIRECT=0
            for dmac in $DIRECT_MACS; do
                [ "$dmac" = "$mac" ] && IS_DIRECT=1 && break
            done
            [ "$IS_DIRECT" -eq 1 ] && continue

            # Check if already mapped
            ALREADY_MAPPED=$(jq -r --arg mac "$mac" '((.mappings // [])[]) | select(.mac == $mac) | .proxy // empty' "$CONFIG_MAPPINGS" 2>/dev/null)

            if [ -z "$ALREADY_MAPPED" ] || [ "$ALREADY_MAPPED" = "DIRECT" ]; then
                # Assign proxy
                if [ "$p_idx" -lt "$PROXY_COUNT" ] || [ "$ALLOW_DUP" = "true" ]; then
                    actual_idx=$(( p_idx % PROXY_COUNT ))
                    RAW_PROXY=$(jq -r --argjson i "$actual_idx" '.auto_proxy.proxy_list[$i]' "$CONFIG_SETTINGS")
                    PNAME="Auto_$(echo "$RAW_PROXY" | md5sum | cut -c1-6)"

                    DEV_NAME="$host"
                    [ -z "$DEV_NAME" ] || [ "$DEV_NAME" = "*" ] && DEV_NAME="Device_$(echo "$mac" | cut -d: -f5,6 | tr -d :)"

                    jq --arg mac "$mac" --arg ip "$ip" --arg name "$DEV_NAME" --arg proxy "$PNAME" '
                      .mappings = [((.mappings // [])[]) | select(.mac != $mac)] + [{mac: $mac, ip: $ip, name: $name, proxy: $proxy}]
                    ' "$CONFIG_MAPPINGS" > "$CONFIG_MAPPINGS.tmp" && [ -s "$CONFIG_MAPPINGS.tmp" ] && mv "$CONFIG_MAPPINGS.tmp" "$CONFIG_MAPPINGS"

                    NEED_APPLY=1
                    p_idx=$((p_idx + 1))
                fi
            fi
        done < /tmp/dhcp.leases
    fi

    if [ "$NEED_APPLY" -eq 1 ] || [ "$RESET_MODE" = "reset" ] || [ "$RESET_MODE" = "1" ]; then
        apply
    fi
}

apply() {
    LOCK_FILE="/tmp/mmo_apply.lock"
    if [ -f "$LOCK_FILE" ]; then
        LOCK_PID=$(cat "$LOCK_FILE" 2>/dev/null)
        if [ -n "$LOCK_PID" ] && kill -0 "$LOCK_PID" 2>/dev/null; then
            echo "[!] Một tiến trình apply khác đang chạy (PID $LOCK_PID). Bỏ qua."
            return 0
        fi
    fi
    echo "$$" > "$LOCK_FILE"
    trap 'rm -f "$LOCK_FILE"' EXIT INT TERM

    # Check if license is expired -> Fallback directly to clean Direct WAN
    IS_EXPIRED=0
    if [ -f "$CONF_DIR/config/license.json" ]; then
        EXP=$(jq -r '.expired_at // 0' "$CONF_DIR/config/license.json" 2>/dev/null)
        NOW=$(date +%s)
        [ -n "$EXP" ] && [ "$EXP" -ne 0 ] && [ "$NOW" -ge "$EXP" ] && IS_EXPIRED=1
    fi

    if [ "$IS_EXPIRED" -eq 1 ]; then
        echo "[!] Hạn bản quyền đã hết. Chuyển sang mạng gốc trực tiếp (Direct WAN)..."
        nft delete table inet mmo_proxy 2>/dev/null || true
        ip rule del fwmark 0x100/0xff00 lookup mmo_proxy 2>/dev/null || true
        ip route flush table mmo_proxy 2>/dev/null || true
        killall sing-box 2>/dev/null || true
        conntrack -F 2>/dev/null || true
        rm -f "$LOCK_FILE"
        echo "[OK] Đang chạy mạng gốc trực tiếp (Direct WAN). Mọi thiết bị vẫn có Internet bình thường!"
        return 0
    fi

    echo "[*] Generating sing-box config..."
    generate_singbox
    
    echo "[*] Checking sing-box configuration syntax..."
    if [ -s "$SINGBOX_CONF" ]; then
        sing-box check -c "$SINGBOX_CONF"
    fi

    echo "[*] Generating nftables rules..."
    generate_firewall

    echo "[*] Checking nftables syntax..."
    nft -c -f "$NFT_RULES"

    echo "[*] Applying nftables table inet mmo_proxy..."
    nft delete table inet mmo_proxy 2>/dev/null || true
    nft -f "$NFT_RULES"

    echo "[*] Ensuring policy routing..."
    ip rule del fwmark 0x100/0xff00 lookup mmo_proxy 2>/dev/null || true
    ip rule add fwmark 0x100/0xff00 lookup mmo_proxy
    ip route replace local default dev lo table mmo_proxy

    echo "[*] Restarting mmo-proxy service..."
    /etc/init.d/mmo-proxy restart

    rm -f "$LOCK_FILE"
    echo "[OK] System applied successfully!"
}

rollback() {
    echo "[*] Rolling back mmo_proxy..."
    nft delete table inet mmo_proxy 2>/dev/null || true
    ip rule del fwmark 0x100/0xff00 lookup mmo_proxy 2>/dev/null || true
    ip route flush table mmo_proxy 2>/dev/null || true
    /etc/init.d/mmo-proxy stop 2>/dev/null || true
    echo "[OK] Rollback complete. Normal traffic restored."
}

on_dhcp() {
    MAC="$1"
    IP="$2"
    HOST="$3"

    [ -z "$MAC" ] && return 0

    AUTO_ENABLE=$(jq -r '.auto_proxy.enable // false' "$CONFIG_SETTINGS" 2>/dev/null)
    DIRECT_MACS=$(jq -r '.direct_wan_devices // [] | .[]' "$CONFIG_SETTINGS" 2>/dev/null)

    # Check if this MAC is in direct whitelist -> already handled by ether saddr link layer
    for dmac in $DIRECT_MACS; do
        [ "$dmac" = "$MAC" ] && return 0
    done

    # If auto-proxy is enabled, check if new device needs proxy assigned
    if [ "$AUTO_ENABLE" = "true" ]; then
        check_auto_proxy
    fi
}

case "$1" in
    gen-singbox) generate_singbox ;;
    gen-firewall) generate_firewall ;;
    apply) apply ;;
    check-auto) shift; check_auto_proxy "$@" ;;
    on-dhcp) shift; on_dhcp "$@" ;;
    rollback) rollback ;;
    *) echo "Usage: $0 {apply|rollback|check-auto|on-dhcp|gen-singbox|gen-firewall}" ;;
esac

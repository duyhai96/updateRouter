# ==============================================================================
# BỘ CÀI ĐẶT & NÂNG CẤP ROUTER TỰ ĐỘNG (LUÔN ĐỒNG BỘ CODE & BẢN MỚI NHẤT)
# Dùng để cài mới sau khi Reset hoặc nâng cấp Router đang chạy
# Hoạt động 100% Offline qua mạng nội bộ - Không cần Internet
# ==============================================================================
$ErrorActionPreference = "Continue"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
if (-not $ScriptDir) { $ScriptDir = (Get-Location).Path }

# Tự động đồng bộ code mới nhất nếu đang ở trong repo phát triển
$parentIndex = Join-Path $ScriptDir "..\index.html"
$parentApi = Join-Path $ScriptDir "..\api"
$parentPack = Join-Path $ScriptDir "..\pack_release.py"
if ((Test-Path $parentIndex) -and (Test-Path $parentApi) -and (Test-Path $parentPack)) {
    Write-Host "[*] Phat hien ma nguon goc tai thu muc cha. Dang tu dong dong goi code moi nhat..." -ForegroundColor Cyan
    try {
        & python $parentPack | Out-Null
    } catch {}
}

# Lấy phiên bản mới nhất từ version.json
$Version = "1.4.7"
$verFile = Join-Path $ScriptDir "version.json"
if (-not (Test-Path $verFile) -and (Test-Path (Join-Path $ScriptDir "..\version.json"))) {
    $verFile = Join-Path $ScriptDir "..\version.json"
}
if (Test-Path $verFile) {
    try {
        $vObj = Get-Content $verFile -Raw | ConvertFrom-Json
        if ($vObj.version) { $Version = $vObj.version }
    } catch {}
}

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "     CONG CU CAI DAT & NANG CAP ROUTER TU DONG (v$Version)           " -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host ""

# 1. Quét tìm IP Router
Write-Host "[1/4] Dang ket noi toi Router..." -ForegroundColor Yellow
$routerIp = $null

try {
    $gw = (Get-NetRoute -DestinationPrefix "0.0.0.0/0" -ErrorAction SilentlyContinue | Select-Object -First 1).NextHop
    if ($gw -and ($gw -like "192.168.*" -or $gw -like "10.*")) {
        $routerIp = $gw
    }
} catch {}

if (-not $routerIp) {
    foreach ($ip in @("192.168.1.1", "192.168.88.1")) {
        $p = Test-Connection -ComputerName $ip -Count 1 -Quiet -ErrorAction SilentlyContinue
        if ($p) {
            $routerIp = $ip
            break
        }
    }
}

if ($routerIp) {
    Write-Host "  -> Phat hien Router hoat dong tai IP: $routerIp" -ForegroundColor Green
}

if (-not $routerIp) {
    Write-Host "[!] Khong tim thay Router. Vui long cam day LAN hoac bat Wi-Fi vao Router." -ForegroundColor Red
    $routerIp = Read-Host "Nhap IP cua Router (mac dinh Enter = 192.168.1.1)"
    if ([string]::IsNullOrWhiteSpace($routerIp)) { $routerIp = "192.168.1.1" }
}

# 2. Kiem tra file bundle
$pkgFile = Join-Path $ScriptDir "mmo_update.tar.gz"
if (-not (Test-Path $pkgFile)) {
    Write-Host "[!] Thieu file goi cai dat: mmo_update.tar.gz trong thu muc nay!" -ForegroundColor Red
    Read-Host "Nhan Enter de thoat..."
    exit 1
}

Write-Host ""
Write-Host "[2/4] Dang nap goi he thong v$Version sang Router ($routerIp)..." -ForegroundColor Yellow
$sshArgs = @("-o", "ConnectTimeout=8", "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=NUL")

scp -O -q @sshArgs "$pkgFile" "root@${routerIp}:/tmp/mmo_update.tar.gz"
if ($LASTEXITCODE -ne 0) {
    Write-Host "  (!) Thu nap qua SSH args du phong..." -ForegroundColor DarkGray
    scp -q @sshArgs "$pkgFile" "root@${routerIp}:/tmp/mmo_update.tar.gz"
}

Write-Host ""
Write-Host "[3/4] Dang giai nen va cau hinh he thong Router..." -ForegroundColor Yellow

$remoteScript = @"
mkdir -p /tmp/mmo_extract /etc/mmo-proxy/bin /etc/mmo-proxy/config /etc/mmo-proxy/expressvpn /www/api /www/mmo/api /www/cgi-bin /etc/dropbear 2>/dev/null

tar -xzf /tmp/mmo_update.tar.gz -C /tmp/mmo_extract 2>/dev/null

if [ -f /tmp/mmo_extract/index.html ]; then
    cp -f /tmp/mmo_extract/index.html /www/index.html
    cp -f /tmp/mmo_extract/index.html /www/mmo/index.html
    chmod 644 /www/index.html /www/mmo/index.html 2>/dev/null
fi

if [ -d /tmp/mmo_extract/api ]; then
    cp -rf /tmp/mmo_extract/api/* /www/api/
    cp -rf /tmp/mmo_extract/api/* /www/mmo/api/
    chmod +x /www/api/* /www/mmo/api/* 2>/dev/null
    ln -sfn /www/api /www/cgi-bin/api 2>/dev/null
fi

for scr in mmo-core.sh mmo-license.sh mmo-wifi.sh mmo-mdns.sh dhcp_hook.sh; do
    if [ -f "/tmp/mmo_extract/`$scr" ]; then
        bname=`$(echo "`$scr" | sed 's/\.sh$//')
        cp -f "/tmp/mmo_extract/`$scr" "/etc/mmo-proxy/bin/`$bname"
        cp -f "/tmp/mmo_extract/`$scr" "/etc/mmo-proxy/bin/`$scr"
        chmod +x "/etc/mmo-proxy/bin/`$bname" "/etc/mmo-proxy/bin/`$scr" 2>/dev/null
    fi
done

[ -f /tmp/mmo_extract/route-up.sh ] && cp -f /tmp/mmo_extract/route-up.sh /etc/mmo-proxy/expressvpn/route-up.sh && chmod +x /etc/mmo-proxy/expressvpn/route-up.sh 2>/dev/null
[ -f /tmp/mmo_extract/route-down.sh ] && cp -f /tmp/mmo_extract/route-down.sh /etc/mmo-proxy/expressvpn/route-down.sh && chmod +x /etc/mmo-proxy/expressvpn/route-down.sh 2>/dev/null
[ -f /tmp/mmo_extract/locations.json ] && cp -f /tmp/mmo_extract/locations.json /etc/mmo-proxy/expressvpn/locations.json
if [ -f /tmp/mmo_extract/expressvpn_configs.tar.gz ]; then
    mkdir -p /etc/mmo-proxy/expressvpn/configs
    tar -xzf /tmp/mmo_extract/expressvpn_configs.tar.gz -C /etc/mmo-proxy/expressvpn/configs/ 2>/dev/null || true
fi
[ -f /tmp/mmo_extract/license_public.pem ] && cp -f /tmp/mmo_extract/license_public.pem /etc/mmo-proxy/config/license_public.pem 2>/dev/null

if [ -f /tmp/mmo_extract/openvpn ]; then
    cp -f /tmp/mmo_extract/openvpn /usr/sbin/openvpn 2>/dev/null || true
    chmod 755 /usr/sbin/openvpn 2>/dev/null || true
fi
if [ -d /tmp/mmo_extract/lib ]; then
    cp -rn /tmp/mmo_extract/lib/* /usr/lib/ 2>/dev/null || true
fi

if [ -d /tmp/mmo_extract/branding ]; then
    mkdir -p /www/branding /www/mmo/branding
    cp -rf /tmp/mmo_extract/branding/* /www/branding/ 2>/dev/null || true
    cp -rf /tmp/mmo_extract/branding/* /www/mmo/branding/ 2>/dev/null || true
fi

if [ -f /tmp/mmo_extract/version.txt ]; then
    cp -f /tmp/mmo_extract/version.txt /www/version.txt
    cp -f /tmp/mmo_extract/version.txt /www/mmo/version.txt
    cp -f /tmp/mmo_extract/version.txt /etc/mmo-proxy/version 2>/dev/null || true
else
    echo "$Version" > /www/version.txt 2>/dev/null
    echo "$Version" > /www/mmo/version.txt 2>/dev/null
    echo "$Version" > /etc/mmo-proxy/version 2>/dev/null || true
fi
[ -f /tmp/mmo_extract/version.json ] && cp -f /tmp/mmo_extract/version.json /www/version.json 2>/dev/null && cp -f /tmp/mmo_extract/version.json /www/mmo/version.json 2>/dev/null

rm -rf /tmp/mmo_extract /tmp/mmo_update.tar.gz

# Cau hinh mang & Firewall
LAN_IP=`$(uci -q get network.lan.ipaddr)
if [ "`$LAN_IP" != "192.168.88.1" ]; then
    uci set network.lan.ipaddr='192.168.88.1'
    uci commit network
fi

uci set firewall.@defaults[0].forward='ACCEPT' 2>/dev/null || true
uci set firewall.@zone[1].masq='1' 2>/dev/null || true
uci set firewall.@zone[1].forward='ACCEPT' 2>/dev/null || true
uci commit firewall 2>/dev/null || true

printf "nameserver 8.8.8.8\nnameserver 1.1.1.1\n" > /tmp/resolv.conf.auto 2>/dev/null || true
uci delete dhcp.@dnsmasq[0].server 2>/dev/null || true
uci add_list dhcp.@dnsmasq[0].server='8.8.8.8' 2>/dev/null || true
uci add_list dhcp.@dnsmasq[0].server='1.1.1.1' 2>/dev/null || true
uci commit dhcp 2>/dev/null || true

[ -x /etc/mmo-proxy/bin/mmo-license ] && /etc/mmo-proxy/bin/mmo-license set-lifetime 2>/dev/null || true

/etc/init.d/uhttpd restart 2>/dev/null || true
/etc/init.d/dnsmasq restart 2>/dev/null || true
/etc/init.d/firewall reload 2>/dev/null || true
[ -x /etc/mmo-proxy/bin/mmo-core ] && /etc/mmo-proxy/bin/mmo-core apply 2>/dev/null || true

if [ "`$LAN_IP" != "192.168.88.1" ]; then
    (sleep 2; /etc/init.d/network restart) >/dev/null 2>&1 &
    echo "RESTARTED_IP_TO_88"
else
    echo "SUCCESS_KEEP_IP"
fi
"@

$out = ssh @sshArgs "root@${routerIp}" $remoteScript

Write-Host ""
Write-Host "[4/4] Thiet lap hoan tat!" -ForegroundColor Green
Write-Host ""
Write-Host "==================================================================" -ForegroundColor Green
Write-Host "        🎉 CAI DAT / NANG CAP ROUTER THANH CONG (v$Version)!         " -ForegroundColor Green
Write-Host "==================================================================" -ForegroundColor Green
Write-Host "  1. Da cai dat he thong & WebUI v$Version hoan chinh."
Write-Host "  2. Da kich hoat Ban quyen Vinh vien (Lifetime License)."
Write-Host "  3. Dia chi quan tri WebUI: http://192.168.88.1" -ForegroundColor Cyan
Write-Host ""
Write-Host "  * Luu y: Neu Router vua reset tu IP 192.168.1.1, vui long rut day" -ForegroundColor Yellow
Write-Host "    LAN cam lai hoac tat bat lai Wi-Fi de nhan dai IP 192.168.88.x." -ForegroundColor Yellow
Write-Host "==================================================================" -ForegroundColor Green
Write-Host ""

Start-Process "http://192.168.88.1"
Write-Host "Nhan Enter de dong cua so."
Read-Host

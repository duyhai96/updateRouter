#!/bin/sh
# /etc/mmo-proxy/bin/mmo-mdns - Lightweight mDNS Device Name Sniffer for OpenWrt
CONF_DIR="/etc/mmo-proxy"
MDNS_FILE="$CONF_DIR/config/mdns_names.json"
mkdir -p "$CONF_DIR/config"
[ -f "$MDNS_FILE" ] || echo "{}" > "$MDNS_FILE"

PIDFILE="/var/run/mmo-mdns.pid"
if [ -f "$PIDFILE" ]; then
    OLDPID=$(cat "$PIDFILE" 2>/dev/null)
    if [ -n "$OLDPID" ] && [ -d "/proc/$OLDPID" ] && [ "$OLDPID" != "$$" ]; then
        exit 0
    fi
fi
echo "$$" > "$PIDFILE"

trap 'rm -f "$PIDFILE"; exit 0' INT TERM EXIT

get_mac_for_ip() {
    _ip="$1"
    [ -z "$_ip" ] && return
    # 1. ARP table
    _m=$(awk -v ip="$_ip" '$1 == ip && $4 ~ /^[0-9a-fA-F:]+$/ {print tolower($4); exit}' /proc/net/arp 2>/dev/null)
    if [ -n "$_m" ] && [ "$_m" != "00:00:00:00:00:00" ]; then
        echo "$_m"
        return
    fi
    # 2. DHCP leases
    _m=$(awk -v ip="$_ip" '$3 == ip {print tolower($2); exit}' /tmp/dhcp.leases 2>/dev/null)
    if [ -n "$_m" ]; then
        echo "$_m"
        return
    fi
    # 3. IP neighbor
    _m=$(ip neigh show dev br-lan "$_ip" 2>/dev/null | awk '{print tolower($5)}' | grep -oE '([0-9a-f]{2}:){5}[0-9a-f]{2}')
    if [ -n "$_m" ]; then
        echo "$_m"
        return
    fi
}

save_name() {
    _mac="$1"
    _name="$2"
    [ -z "$_mac" ] || [ -z "$_name" ] && return
    # Strictly reject protocol tokens, transport layers and keywords
    echo "$_name" | grep -qiE '^_|^(tcp|udp|_tcp|_udp|local|b|dns-sd|sleep-proxy|companion-link)$' && return
    # Clean name
    _name=$(echo "$_name" | tr -d '\r\n"' | sed 's/^[ \t]*//;s/[ \t]*$//')
    [ -z "$_name" ] && return

    _curr=$(jq -r --arg m "$_mac" '.[$m] // empty' "$MDNS_FILE" 2>/dev/null)
    if [ "$_curr" != "$_name" ]; then
        jq --arg m "$_mac" --arg n "$_name" '.[$m] = $n' "$MDNS_FILE" > "$MDNS_FILE.tmp" 2>/dev/null && mv "$MDNS_FILE.tmp" "$MDNS_FILE"
    fi
}

if ! which tcpdump >/dev/null 2>&1; then
    exit 1
fi

SRC_IP=""
tcpdump -i br-lan -nn -l -s 1500 -A 'udp port 5353' 2>/dev/null | while read -r line; do
    case "$line" in
        *"IP 192.168.88."*".5353 > "*)
            SRC_IP=$(echo "$line" | sed -nE 's/.*IP (192\.168\.88\.[0-9]+)\.5353 > .*/\1/p')
            ;;
        *)
            if [ -n "$SRC_IP" ] && [ "$SRC_IP" != "192.168.88.1" ]; then
                DETECTED_NAME=""

                # 1. Friendly Name (fn=...)
                FNAME=$(echo "$line" | grep -oE 'fn=[^;,[:cntrl:]]+' | head -n1 | cut -d= -f2-)
                if [ -n "$FNAME" ] && [ "$FNAME" != "null" ]; then
                    DETECTED_NAME="$FNAME"
                fi

                # 2. Device Model (model=iPhone... or model=iPad...)
                if [ -z "$DETECTED_NAME" ]; then
                    MODEL=$(echo "$line" | grep -oE 'model=[^;,[:cntrl:]]+' | head -n1 | cut -d= -f2-)
                    if [ -n "$MODEL" ]; then
                        DETECTED_NAME="$MODEL"
                    fi
                fi

                # 3. Genuine Hostname ending in .local (exclude tcp, udp, etc.)
                if [ -z "$DETECTED_NAME" ]; then
                    HLOCAL=$(echo "$line" | grep -oE '[a-zA-Z0-9][a-zA-Z0-9_-]*\.local' | sed 's/\.local$//' | grep -vE '^(tcp|udp|local|b|arpa)$' | head -n1)
                    if [ -n "$HLOCAL" ]; then
                        DETECTED_NAME="$HLOCAL"
                    fi
                fi

                # 4. Apple Continuity / Bonjour services
                if [ -z "$DETECTED_NAME" ]; then
                    if echo "$line" | grep -qE '_apple-mobdev2|_companion-link|_airplay|_raop|_sleep-proxy'; then
                        DETECTED_NAME="iPhone"
                    fi
                fi

                if [ -n "$DETECTED_NAME" ]; then
                    MAC=$(get_mac_for_ip "$SRC_IP")
                    if [ -n "$MAC" ]; then
                        save_name "$MAC" "$DETECTED_NAME"
                    fi
                fi
            fi
            ;;
    esac
done

# ==============================================================================
# TOOL NÂNG CẤP ROUTER KHÁCH HÀNG (LUÔN LÀ BẢN MỚI NHẤT)
# Tự động phát file Offline qua mạng LAN nội bộ (Bypass 100% chặn mạng & SSL)
# ==============================================================================
$ErrorActionPreference = "Continue"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
if (-not $ScriptDir) { $ScriptDir = (Get-Location).Path }

# Tự động đồng bộ nếu chạy từ thư mục dev
$parentPack = Join-Path $ScriptDir "..\pack_release.py"
if ((Test-Path (Join-Path $ScriptDir "..\index.html")) -and (Test-Path $parentPack)) {
    try {
        & python $parentPack | Out-Null
    } catch {}
}

# Đọc version chuẩn
$targetVer = "1.4.7"
$targetChange = "Cập nhật tối ưu hệ thống toàn diện, sửa lỗi và ổn định kết nối."
foreach ($vf in @((Join-Path $ScriptDir "version.json"), (Join-Path $ScriptDir "dist\version.json"), (Join-Path $ScriptDir "..\version.json"))) {
    if (Test-Path $vf) {
        try {
            $meta = Get-Content $vf -Raw | ConvertFrom-Json
            if ($meta.version) { $targetVer = $meta.version }
            if ($meta.changelog) { $targetChange = $meta.changelog }
            break
        } catch {}
    }
}

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "    CONG CU NANG CAP ROUTER KHACH HANG LEN BAN MOI NHAT (v$targetVer)  " -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host ""

# 1. Tìm Router IP
Write-Host "[1/5] Dang tim kiem dia chi IP Router..." -ForegroundColor Yellow
$routerIp = $null
foreach ($ip in @("192.168.88.1", "192.168.1.1")) {
    try {
        $res = Invoke-RestMethod -Uri "http://${ip}/api/status" -TimeoutSec 2 -ErrorAction SilentlyContinue
        if ($res -and $res.status -eq "ok") {
            $routerIp = $ip
            break
        }
    } catch {}
}

if (-not $routerIp) {
    Write-Host "[!] Khong the ket noi toi Router (192.168.88.1 hoac 192.168.1.1)!" -ForegroundColor Red
    Write-Host "Vui long kiem tra lai day LAN hoac ket noi Wi-Fi toi Router." -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Nhan Enter de thoat..."
    exit 1
}
Write-Host "  [OK] Tim thay Router tai: http://$routerIp" -ForegroundColor Green

# 2. Tìm IP card mạng máy tính kết nối với Router
$subnetPrefix = $routerIp.Substring(0, $routerIp.LastIndexOf('.') + 1)
$localIp = (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress.StartsWith($subnetPrefix) } | Select-Object -First 1).IPAddress

if (-not $localIp) {
    try {
        $localIp = (Get-NetIPConfiguration | Where-Object { $_.IPv4DefaultGateway.NextHop -eq $routerIp }).IPv4Address.IPAddress
    } catch {}
}

if (-not $localIp) {
    $localIp = Read-Host "Nhap IP may tinh cua ban trong mang Router (vi du: 192.168.88.150)"
}
Write-Host "  [OK] IP May Tinh trong mang Router: $localIp" -ForegroundColor Green

# 3. Chuẩn bị file cập nhật trên máy tính
Write-Host ""
Write-Host "[2/5] Dang chuan bi goi cap nhat v$targetVer tren may tinh..." -ForegroundColor Yellow
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13

$pkgFile = Join-Path $ScriptDir "mmo_update.tar.gz"
$verFile = Join-Path $ScriptDir "version.json"

if (-not (Test-Path $pkgFile) -and (Test-Path "$ScriptDir\dist\mmo_update.tar.gz")) {
    $pkgFile = "$ScriptDir\dist\mmo_update.tar.gz"
}
if (-not (Test-Path $verFile) -and (Test-Path "$ScriptDir\dist\version.json")) {
    $verFile = "$ScriptDir\dist\version.json"
}

if (-not (Test-Path $pkgFile)) {
    Write-Host "  -> Dang tai goi cap nhat tu Cloudflare jsDelivr CDN..." -ForegroundColor Cyan
    try {
        Invoke-WebRequest -Uri "https://cdn.jsdelivr.net/gh/duyhai96/updateRouter@main/mmo_update.tar.gz" -OutFile "$ScriptDir\mmo_update.tar.gz" -UseBasicParsing -TimeoutSec 30
        $pkgFile = "$ScriptDir\mmo_update.tar.gz"
    } catch {
        Write-Host "  (!) Thu tai tu GitHub Raw..." -ForegroundColor DarkGray
        Invoke-WebRequest -Uri "https://raw.githubusercontent.com/duyhai96/updateRouter/main/mmo_update.tar.gz" -OutFile "$ScriptDir\mmo_update.tar.gz" -UseBasicParsing -TimeoutSec 30
        $pkgFile = "$ScriptDir\mmo_update.tar.gz"
    }
}

# Tính SHA256 chuẩn của file mmo_update.tar.gz và tạo version.json khớp 100%
$calcSha = (Get-FileHash -Algorithm SHA256 $pkgFile).Hash.ToLower()
$releaseDate = (Get-Date).ToString("yyyy-MM-dd")
$versionJsonContent = @"
{
    "version": "$targetVer",
    "release_date": "$releaseDate",
    "changelog": "$targetChange",
    "package": "mmo_update.tar.gz",
    "sha256": "$calcSha"
}
"@
Set-Content -Path $verFile -Value $versionJsonContent -Encoding UTF8

Write-Host "  [OK] File cap nhat v$targetVer & SHA256 da san sang tren may tinh!" -ForegroundColor Green

# 4. Khởi động Local HTTP MiniServer trên máy tính
Write-Host ""
Write-Host "[3/5] Khoi dong may chu truyen file noi bo (LAN Port 8088)..." -ForegroundColor Yellow
$csharpServer = @'
using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

public class MiniServer {
    public static TcpListener listener;
    public static string baseDir;

    public static void Start(int port, string dir) {
        baseDir = dir;
        listener = new TcpListener(IPAddress.Any, port);
        listener.Start();
        Thread thread = new Thread(() => {
            while (true) {
                try {
                    TcpClient client = listener.AcceptTcpClient();
                    ThreadPool.QueueUserWorkItem((obj) => {
                        TcpClient c = (TcpClient)obj;
                        try {
                            NetworkStream stream = c.GetStream();
                            StreamReader reader = new StreamReader(stream);
                            string line = reader.ReadLine();
                            if (line != null && line.StartsWith("GET ")) {
                                string[] parts = line.Split(' ');
                                string path = parts[1].Split('?')[0].TrimStart('/');
                                string fullPath = Path.Combine(baseDir, path);
                                if (!File.Exists(fullPath)) {
                                    fullPath = Path.Combine(Path.Combine(baseDir, "dist"), path);
                                }
                                if (File.Exists(fullPath)) {
                                    byte[] data = File.ReadAllBytes(fullPath);
                                    string header = "HTTP/1.1 200 OK\r\nContent-Length: " + data.Length + "\r\nConnection: close\r\n\r\n";
                                    byte[] headerBytes = System.Text.Encoding.ASCII.GetBytes(header);
                                    stream.Write(headerBytes, 0, headerBytes.Length);
                                    stream.Write(data, 0, data.Length);
                                    stream.Flush();
                                } else {
                                    byte[] nf = System.Text.Encoding.ASCII.GetBytes("HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n");
                                    stream.Write(nf, 0, nf.Length);
                                }
                            }
                            c.Close();
                        } catch {}
                    }, client);
                } catch { break; }
            }
        });
        thread.IsBackground = true;
        thread.Start();
    }

    public static void Stop() {
        try { if (listener != null) listener.Stop(); } catch {}
    }
}
'@

try {
    Add-Type -TypeDefinition $csharpServer -ErrorAction SilentlyContinue
} catch {}

$serverPort = 8088
try {
    [MiniServer]::Stop()
} catch {}
[MiniServer]::Start($serverPort, $ScriptDir)
Write-Host "  [OK] May chu noi bo dang phat tai: http://${localIp}:${serverPort}" -ForegroundColor Green

# 5. Cấu hình Router nạp file trực tiếp từ PC
Write-Host ""
Write-Host "[4/5] Dieu huong Router nap ban cap nhat tu May Tinh qua LAN..." -ForegroundColor Yellow
$bodySave = @{
    action = "save_config"
    update_url = "http://${localIp}:${serverPort}"
} | ConvertTo-Json

try {
    $null = Invoke-RestMethod -Uri "http://${routerIp}/api/update?action=save_config" -Method Post -ContentType "application/json" -Body $bodySave -TimeoutSec 8
    Write-Host "  [OK] Router da ket noi kenh truyen file noi bo!" -ForegroundColor Green
} catch {
    Write-Host "  (!) Loi luu kenh: $_" -ForegroundColor Yellow
}

# 6. Kích hoạt cập nhật
Write-Host ""
Write-Host "[5/5] Dang ra lenh Router tiep nhan goi va cai dat v$targetVer..." -ForegroundColor Yellow
Write-Host "      (Router dang copy goi & cai dat, vui long cho 10-25 giay...)" -ForegroundColor DarkGray

$adminPass = ""
$bodyApply = @{ action = "apply"; admin_password = $adminPass } | ConvertTo-Json
$isSuccess = $false

try {
    $resApply = Invoke-RestMethod -Uri "http://${routerIp}/api/update?action=apply" -Method Post -ContentType "application/json" -Body $bodyApply -TimeoutSec 60
    if ($resApply.status -eq "ok") {
        $isSuccess = $true
        Write-Host ""
        Write-Host "==================================================================" -ForegroundColor Green
        Write-Host "       🎉 NANG CAP ROUTER THANH CONG LEN BAN MOI (v$targetVer)!        " -ForegroundColor Green
        Write-Host "==================================================================" -ForegroundColor Green
        Write-Host "  1. Da giai nen va cai dat ban moi v$targetVer vao Router thanh cong."
        Write-Host "  2. Da sua triet de loi mat ket noi may chu cap nhat."
        Write-Host "  3. Dia chi quan tri: http://${routerIp}" -ForegroundColor Cyan
    } else {
        if ($resApply.message -like "*Mat khau*") {
            Write-Host "Router yeu cau Mat khau Quan tri de xac thuc." -ForegroundColor Yellow
            $adminPass = Read-Host "Nhap Mat khau Router (Admin Password)"
            $bodyApply2 = @{ action = "apply"; admin_password = $adminPass } | ConvertTo-Json
            $resApply2 = Invoke-RestMethod -Uri "http://${routerIp}/api/update?action=apply" -Method Post -ContentType "application/json" -Body $bodyApply2 -TimeoutSec 60
            if ($resApply2.status -eq "ok") {
                $isSuccess = $true
                Write-Host "  [OK] Nang cap thanh cong: $($resApply2.message)" -ForegroundColor Green
            } else {
                Write-Host "  [!] That bai: $($resApply2.message)" -ForegroundColor Red
            }
        } else {
            Write-Host "  [!] Loi tu Router: $($resApply.message)" -ForegroundColor Red
        }
    }
} catch {
    Write-Host "  (!) Router da hoan tat va dang khoi dong lai uhttpd..." -ForegroundColor Yellow
    $isSuccess = $true
}

# Dọn dẹp máy chủ mini & Đặt lại kênh OTA trên Router sang CDN Fastly
[MiniServer]::Stop()

if ($isSuccess) {
    try {
        Start-Sleep -Seconds 2
        $bodyResetOta = @{
            action = "save_config"
            update_url = "https://raw.githubusercontent.com/duyhai96/updateRouter/main"
        } | ConvertTo-Json
        $null = Invoke-RestMethod -Uri "http://${routerIp}/api/update?action=save_config" -Method Post -ContentType "application/json" -Body $bodyResetOta -TimeoutSec 5 -ErrorAction SilentlyContinue
    } catch {}
    
    Start-Process "http://${routerIp}"
}

Write-Host ""
Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "Hoan tat qua trinh! Nhan Enter de dong cua so."
Read-Host

# ==============================================================================
# SCRIPT CUU MANG VA SUA LOI WI-FI ROUTER (192.168.88.1)
# ==============================================================================
$ErrorActionPreference = "Continue"
$router = "192.168.88.1"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
if (-not $ScriptDir) { $ScriptDir = (Get-Location).Path }

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "        CONG CU CUU MANG VA SUA LOI WI-FI ROUTER 192.168.88.1     " -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host ""

# 1. Kiem tra va tu dong ket noi Wi-Fi Router
$curSsid = (netsh wlan show interfaces | Select-String "^\s*SSID\s*:\s*(.+)$" | ForEach-Object { $_.Matches.Groups[1].Value.Trim() })
Write-Host "[1/4] Wi-Fi hien tai: $curSsid" -ForegroundColor Cyan

if ($curSsid -notlike "*ImmortalWrt*" -and $curSsid -notlike "*WifiSocks*") {
    Write-Host "  [*] Dang tu dong chuyen sang Wi-Fi Router (ImmortalWrt-5G / 2.4G)..." -ForegroundColor Yellow
    netsh wlan set profileparameter name="DUY HAI 5G" connectionmode=manual 2>$null
    netsh wlan connect name="ImmortalWrt-5G" 2>$null
    netsh wlan connect name="ImmortalWrt-5G 2" 2>$null
    netsh wlan connect name="ImmortalWrt-2.4G" 2>$null
    for ($i = 1; $i -le 6; $i++) {
        Start-Sleep -Seconds 1
        $chk = (netsh wlan show interfaces | Select-String "^\s*SSID\s*:\s*(.+)$" | ForEach-Object { $_.Matches.Groups[1].Value.Trim() })
        if ($chk -like "*ImmortalWrt*" -or $chk -like "*WifiSocks*") {
            Write-Host "  [OK] Da ket noi Wi-Fi: $chk" -ForegroundColor Green
            break
        }
    }
}

# 2. Dat IP tinh tam thoi de dam bao thong tuyen 100%
Write-Host ""
Write-Host "[2/4] Kiem tra ket noi toi Router 192.168.88.1..." -ForegroundColor Yellow
$p = Test-Connection -ComputerName $router -Count 1 -Quiet -ErrorAction SilentlyContinue
if (-not $p) {
    Write-Host "  [*] Thiet lap IP tinh tam thoi 192.168.88.55 de bat tay voi Router..." -ForegroundColor DarkGray
    netsh interface ip set address "Wi-Fi" static 192.168.88.55 255.255.255.0 192.168.88.1 2>$null
    Start-Sleep -Seconds 2
    $p = Test-Connection -ComputerName $router -Count 1 -Quiet -ErrorAction SilentlyContinue
}

if (-not $p) {
    Write-Host "[!] Van chua the ping 192.168.88.1!" -ForegroundColor Red
    Write-Host "    Vui long kiem tra xem Router co dang bat nguon khong hoac rut nguon cam lai." -ForegroundColor Yellow
    netsh interface ip set address "Wi-Fi" dhcp 2>$null
    netsh wlan set profileparameter name="DUY HAI 5G" connectionmode=auto 2>$null
    Read-Host "Nhan Enter de thoat..."
    exit 1
}
Write-Host "  [OK] Ket noi toi Router 192.168.88.1: THANH CONG!" -ForegroundColor Green

# 3. Dong bo code moi (WebUI co nut Bat/Tat Wi-Fi) va don sach Wi-Fi loi
Write-Host ""
Write-Host "[3/4] Dang sua loi va cap nhat tinh nang Bat/Tat Wi-Fi len Router..." -ForegroundColor Yellow
$sshArgs = @("-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=NUL", "-o", "ConnectTimeout=6")
$scpArgs = @("-O", "-q", "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=NUL", "-o", "ConnectTimeout=6")

# Day index.html, mmo-wifi.sh, api/wifi
if (Test-Path "$ScriptDir\..\index.html") {
    scp @scpArgs "$ScriptDir\..\index.html" "root@${router}:/www/index.html" 2>$null
    scp @scpArgs "$ScriptDir\..\index.html" "root@${router}:/www/mmo/index.html" 2>$null
} elseif (Test-Path "$ScriptDir\index.html") {
    scp @scpArgs "$ScriptDir\index.html" "root@${router}:/www/index.html" 2>$null
    scp @scpArgs "$ScriptDir\index.html" "root@${router}:/www/mmo/index.html" 2>$null
}

if (Test-Path "$ScriptDir\..\mmo-wifi.sh") {
    scp @scpArgs "$ScriptDir\..\mmo-wifi.sh" "root@${router}:/etc/mmo-proxy/bin/mmo-wifi" 2>$null
}
if (Test-Path "$ScriptDir\..\api\wifi") {
    scp @scpArgs "$ScriptDir\..\api\wifi" "root@${router}:/www/api/wifi" 2>$null
    scp @scpArgs "$ScriptDir\..\api\wifi" "root@${router}:/www/mmo/api/wifi" 2>$null
}

$cleanCmd = @'
# 1. Don dep cac section Wi-Fi ao bi loi MAC
for mmo_sec in $(uci show wireless 2>/dev/null | grep "=wifi-iface" | grep "mmo_wifi_" | cut -d. -f2 | cut -d= -f1); do
    uci delete wireless.$mmo_sec 2>/dev/null || true
done

# 2. Dam bao Wi-Fi goc 2.4G va 5G duoc mo
uci set wireless.default_radio0.disabled='0' 2>/dev/null || true
uci set wireless.default_radio1.disabled='0' 2>/dev/null || true
uci commit wireless 2>/dev/null || true

# 3. Phan quyen va khu CRLF
sed -i 's/\r$//' /etc/mmo-proxy/bin/* /www/api/* 2>/dev/null || true
chmod +x /etc/mmo-proxy/bin/* /www/api/* 2>/dev/null || true

# 4. Khoi dong lai song Wi-Fi sach
(sleep 1; wifi reload) >/dev/null 2>&1 &
echo SUCCESS_CLEANED_WIFI
'@

$res = ssh @sshArgs "root@${router}" $cleanCmd

# 4. Tra ve DHCP va hoan tat
Write-Host ""
Write-Host "[4/4] Dang hoan tat va tra lai card mang ve tu dong (DHCP)..." -ForegroundColor Yellow
netsh interface ip set address "Wi-Fi" dhcp 2>$null
netsh wlan set profileparameter name="DUY HAI 5G" connectionmode=auto 2>$null
Start-Sleep -Seconds 3

Write-Host ""
Write-Host "==================================================================" -ForegroundColor Green
Write-Host "     DA KHOI PHUC VA CAP NHAT GIAO DIEN ROUTER THANH CONG!        " -ForegroundColor Green
Write-Host "==================================================================" -ForegroundColor Green
Write-Host "  1. Da don sach cac Wi-Fi ao gay treo song mang."
Write-Host "  2. Da cap nhat nut [Bat / Tat] cho tung mang Wi-Fi."
Write-Host "  3. Dia chi WebUI: http://192.168.88.1" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Green
Write-Host ""

Start-Process "http://192.168.88.1"

#!/bin/sh
# /etc/mmo-proxy/bin/mmo-wifi
# Multi-SSID and Vendor BSSID Spoofing for MediaTek MT7981

gen_mac() {
    BRAND="$1"
    OUI="00:18:F8" # Default Linksys
    case "$BRAND" in
        cisco)   OUI="00:26:0B" ;;
        asus)    OUI="04:D9:F5" ;;
        zte)     OUI="FC:AB:F5" ;;
        netgear) OUI="20:4E:7F" ;;
        apple)   OUI="AC:BC:32" ;;
        tplink)  OUI="50:C7:BF" ;;
        *)       OUI="00:18:F8" ;;
    esac
    BYTE4=$(hexdump -n 1 -e '1/1 "%02X"' /dev/urandom 2>/dev/null || printf "%02X" $((RANDOM % 256)))
    BYTE5=$(hexdump -n 1 -e '1/1 "%02X"' /dev/urandom 2>/dev/null || printf "%02X" $((RANDOM % 256)))
    BYTE6=$(hexdump -n 1 -e '1/1 "%02X"' /dev/urandom 2>/dev/null || printf "%02X" $((RANDOM % 256)))
    echo "$OUI:$BYTE4:$BYTE5:$BYTE6"
}

cmd_list() {
    # Dump all wifi-iface in JSON
    jq -n --arg dummy "" '[]' > /tmp/wifi_list.json
    NUM_IFACES=$(uci show wireless | grep '=wifi-iface' | wc -l)
    idx=0
    while [ "$idx" -lt "$NUM_IFACES" ]; do
        SSID=$(uci -q get wireless.@wifi-iface[$idx].ssid)
        NET=$(uci -q get wireless.@wifi-iface[$idx].network)
        
        # Exclude VPN dedicated Wi-Fi network from MMO proxy Wi-Fi list
        if [ "$NET" = "vpnwifi" ] || [ "$SSID" = "MMO_ExpressVPN" ]; then
            idx=$((idx + 1))
            continue
        fi

        DEV=$(uci -q get wireless.@wifi-iface[$idx].device)
        ENC=$(uci -q get wireless.@wifi-iface[$idx].encryption)
        [ -z "$ENC" ] && ENC="none"
        KEY=$(uci -q get wireless.@wifi-iface[$idx].key)
        [ -z "$KEY" ] && KEY=""
        MAC=$(uci -q get wireless.@wifi-iface[$idx].macaddr)
        [ -z "$MAC" ] && MAC=""
        HIDDEN=$(uci -q get wireless.@wifi-iface[$idx].hidden)
        [ -z "$HIDDEN" ] && HIDDEN="0"
        
        BAND="5G"
        [ "$DEV" = "MT7981_1_1" ] && BAND="2.4G"

        if [ -n "$SSID" ]; then
            jq --arg ssid "$SSID" \
               --arg band "$BAND" \
               --arg dev "$DEV" \
               --arg enc "$ENC" \
               --arg key "$KEY" \
               --arg mac "$MAC" \
               --arg hidden "$HIDDEN" \
               '. += [{ssid: $ssid, band: $band, device: $dev, encryption: $enc, key: $key, mac: $mac, hidden: ($hidden == "1")}]' \
               /tmp/wifi_list.json > /tmp/wifi_list.tmp && mv /tmp/wifi_list.tmp /tmp/wifi_list.json
        fi
        idx=$((idx + 1))
    done
    cat /tmp/wifi_list.json
}

cmd_create_multiple() {
    COUNT="$1"
    BAND="$2" # 2g or 5g
    PREFIX="$3"
    BRAND="${4:-linksys}"
    PASSWORD="$5"
    HIDDEN="${6:-0}"

    [ -z "$COUNT" ] && COUNT=4
    [ -z "$BAND" ] && BAND="5g"
    [ -z "$PREFIX" ] && PREFIX="WifiSocks"

    DEVICE="MT7981_1_2" # 5G
    [ "$BAND" = "2g" ] && DEVICE="MT7981_1_1"

    i=1
    while [ "$i" -le "$COUNT" ]; do
        SSID="${PREFIX}_$(printf "%02d" $i)"
        MAC=$(gen_mac "$BRAND")

        SECTION="mmo_wifi_${BAND}_${i}"
        uci -q delete wireless.$SECTION || true
        uci set wireless.$SECTION=wifi-iface
        uci set wireless.$SECTION.device="$DEVICE"
        uci set wireless.$SECTION.network='lan'
        uci set wireless.$SECTION.mode='ap'
        uci set wireless.$SECTION.ssid="$SSID"
        uci set wireless.$SECTION.macaddr="$MAC"
        uci set wireless.$SECTION.hidden="$HIDDEN"

        if [ -n "$PASSWORD" ] && [ ${#PASSWORD} -ge 8 ]; then
            uci set wireless.$SECTION.encryption='psk2'
            uci set wireless.$SECTION.key="$PASSWORD"
        else
            uci set wireless.$SECTION.encryption='none'
        fi

        i=$((i + 1))
    done

    uci commit wireless
    wifi reload >/dev/null 2>&1 &
    echo "{\"status\":\"ok\",\"message\":\"Created $COUNT WiFi networks successfully\"}"
}

cmd_delete_single() {
    SSID="$1"
    [ -z "$SSID" ] && exit 1

    if [ "$SSID" = "MMO_ExpressVPN" ]; then
        echo '{"status":"error","message":"Wi-Fi MMO_ExpressVPN là Wi-Fi chuyên dụng VPN, vui lòng quản lý tại tab Quản lý VPN!"}'
        return 0
    fi

    NUM_IFACES=$(uci show wireless | grep '=wifi-iface' | wc -l)
    idx=0
    while [ "$idx" -lt "$NUM_IFACES" ]; do
        CUR_SSID=$(uci -q get wireless.@wifi-iface[$idx].ssid)
        if [ "$CUR_SSID" = "$SSID" ]; then
            uci delete wireless.@wifi-iface[$idx]
            uci commit wireless
            wifi reload >/dev/null 2>&1 &
            echo '{"status":"ok","message":"WiFi network deleted"}'
            return 0
        fi
        idx=$((idx + 1))
    done
    echo '{"status":"error","message":"SSID not found"}'
}

cmd_delete_all() {
    # Keep only default radio0 and radio1 interfaces, remove custom
    NUM_IFACES=$(uci show wireless | grep '=wifi-iface' | wc -l)
    idx=$((NUM_IFACES - 1))
    while [ "$idx" -ge 0 ]; do
        SEC_NAME=$(uci show wireless | grep "=wifi-iface" | sed -n "$((idx + 1))p" | cut -d'.' -f2 | cut -d'=' -f1)
        if echo "$SEC_NAME" | grep -q "mmo_wifi_"; then
            uci delete wireless.$SEC_NAME
        fi
        idx=$((idx - 1))
    done
    uci commit wireless
    wifi reload >/dev/null 2>&1 &
    echo '{"status":"ok","message":"All custom WiFi networks removed"}'
}

cmd_update_wifi() {
    OLD_SSID="$1"
    NEW_SSID="$2"
    PASSWORD="$3"
    HIDDEN="${4:-0}"

    [ -z "$OLD_SSID" ] && exit 1
    [ -z "$NEW_SSID" ] && NEW_SSID="$OLD_SSID"

    if [ "$OLD_SSID" = "MMO_ExpressVPN" ]; then
        echo '{"status":"error","message":"Wi-Fi MMO_ExpressVPN được quản lý tại tab Quản lý VPN!"}'
        return 0
    fi

    if [ -n "$PASSWORD" ] && [ ${#PASSWORD} -lt 8 ]; then
        echo '{"status":"error","message":"Mật khẩu Wi-Fi phải có tối thiểu 8 ký tự!"}'
        exit 0
    fi

    NUM_IFACES=$(uci show wireless | grep '=wifi-iface' | wc -l)
    idx=0
    while [ "$idx" -lt "$NUM_IFACES" ]; do
        CUR_SSID=$(uci -q get wireless.@wifi-iface[$idx].ssid)
        if [ "$CUR_SSID" = "$OLD_SSID" ]; then
            uci set wireless.@wifi-iface[$idx].ssid="$NEW_SSID"
            uci set wireless.@wifi-iface[$idx].hidden="$HIDDEN"
            if [ -n "$PASSWORD" ] && [ ${#PASSWORD} -ge 8 ]; then
                uci set wireless.@wifi-iface[$idx].encryption='psk2'
                uci set wireless.@wifi-iface[$idx].key="$PASSWORD"
            elif [ -z "$PASSWORD" ]; then
                uci set wireless.@wifi-iface[$idx].encryption='none'
                uci -q delete wireless.@wifi-iface[$idx].key
            fi
            uci commit wireless
            wifi reload >/dev/null 2>&1 &
            echo "{\"status\":\"ok\",\"message\":\"Đã cập nhật Wi-Fi $NEW_SSID thành công\"}"
            return 0
        fi
        idx=$((idx + 1))
    done
    echo '{"status":"error","message":"SSID not found"}'
}

case "$1" in
    list) cmd_list ;;
    create) shift; cmd_create_multiple "$@" ;;
    update) shift; cmd_update_wifi "$@" ;;
    delete) shift; cmd_delete_single "$@" ;;
    delete-all) cmd_delete_all ;;
    *) echo "Usage: $0 {list|create|update|delete|delete-all}" ;;
esac

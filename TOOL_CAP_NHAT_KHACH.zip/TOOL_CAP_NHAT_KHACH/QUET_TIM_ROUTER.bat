@echo off
setlocal enabledelayedexpansion
title DÒ TÌM IP ROUTER CHÍNH XÁC
cd /d "%~dp0"

:: Xin quyen Administrator
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Dang yeu cau quyen Administrator de do tim Router...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo ==================================================================
echo         DANG DO TIM CHINH XAC IP CUA ROUTER TREN DANG MANG
echo ==================================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
"$ad = Get-NetAdapter | Where-Object { $_.Status -eq 'Up' -and $_.Virtual -ne $true } | Select-Object -First 1; " ^
"if (-not $ad) { " ^
"    $ad = Get-NetAdapter | Where-Object { $_.Status -ne 'Disabled' -and $_.Virtual -ne $true } | Select-Object -First 1; " ^
"}; " ^
"if (-not $ad) { Write-Host 'KHONG TIM THAY CARD MANG NAO DANG KET NOI!' -ForegroundColor Red; exit }; " ^
"Write-Host ('[+] Dang thao tac tren card: ' + $ad.Name) -ForegroundColor Cyan; " ^
"netsh interface ip set address $ad.Name static 192.168.88.50 255.255.255.0 192.168.88.1 | Out-Null; " ^
"netsh interface ip add address $ad.Name 192.168.1.50 255.255.255.0 | Out-Null; " ^
"netsh interface ip add address $ad.Name 192.168.0.50 255.255.255.0 | Out-Null; " ^
"netsh interface ip add address $ad.Name 192.168.6.50 255.255.255.0 | Out-Null; " ^
"Start-Sleep -Seconds 1; " ^
"$found = $null; " ^
"foreach ($ip in @('192.168.88.1', '192.168.1.1', '192.168.0.1', '192.168.6.1')) { " ^
"    Write-Host ('  - Dang ping thu: ' + $ip + ' ...') -NoNewline; " ^
"    if (Test-Connection -ComputerName $ip -Count 1 -Quiet -TimeoutSeconds 1) { " ^
"        Write-Host ' [OK - TIM THAY!]' -ForegroundColor Green; " ^
"        $found = $ip; " ^
"        break; " ^
"    } else { " ^
"        Write-Host ' [Khong phan hoi]' -ForegroundColor DarkGray; " ^
"    } " ^
"}; " ^
"Write-Host ''; " ^
"if ($found) { " ^
"    Write-Host '======================================================' -ForegroundColor Green; " ^
"    Write-Host ('  🎉 DA TIM THAY ROUTER TAI IP: ' + $found) -ForegroundColor Green; " ^
"    Write-Host '======================================================' -ForegroundColor Green; " ^
"    Write-Host ('  Dang mo trinh duyet vao: http://' + $found) -ForegroundColor Cyan; " ^
"    Start-Process ('http://' + $found); " ^
"} else { " ^
"    Write-Host '======================================================' -ForegroundColor Red; " ^
"    Write-Host '  KHONG PING DUOC BAT KY DAI IP NAO CUA ROUTER!' -ForegroundColor Red; " ^
"    Write-Host '======================================================' -ForegroundColor Red; " ^
"    Write-Host '  Bang ARP hien tai tren may tinh:' -ForegroundColor Yellow; " ^
"    arp -a; " ^
"}"

echo.
echo Nhan phim bat ky de thoat...
pause >nul

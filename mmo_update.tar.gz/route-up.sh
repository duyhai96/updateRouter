#!/bin/sh
# /etc/mmo-proxy/expressvpn/route-up.sh
# Supports single tunnel (slot="") or multi-instance slots ($1 = 1, 2, 3...)

# Parse SLOT and DEV cleanly:
# If called by OpenVPN as route-up: $1="tun_evpn1", env $dev="tun_evpn1"
# If called by api_expressvpn.sh: $1="1"
ARG1="$1"
SLOT=$(echo "$ARG1" | sed 's/[^0-9]//g')
[ -z "$SLOT" ] && [ -n "$dev" ] && SLOT=$(echo "$dev" | sed 's/[^0-9]//g')
[ -z "$SLOT" ] && SLOT=1

dev="tun_evpn${SLOT}"
TABLE=$((200 + SLOT))

# Find VPN Wi-Fi device
WIFI_DEV=$(uci -q get wireless.vpn_wifi.device)
WIFI_IF="rax1"
[ "$WIFI_DEV" = "MT7981_1_1" ] && WIFI_IF="ra1"

# Flush table and set default VPN route for this tunnel
ip route flush table "$TABLE" 2>/dev/null || true
# Point-to-point TUN interfaces route directly through dev:
ip route replace default dev "$dev" table "$TABLE"

# Ensure local subnet routes in this table so router can send replies (e.g. DNS) back to clients
ip route replace 192.168.99.0/24 dev "$WIFI_IF" table "$TABLE" 2>/dev/null || true
ip route replace 192.168.88.0/24 dev br-lan table "$TABLE" 2>/dev/null || true

SUBNET=$(ip -4 addr show dev "$dev" 2>/dev/null | grep -o 'inet [0-9.]*' | awk '{print $2}' | awk -F. '{print $1"."$2".0.0/16"}')
if [ -n "$SUBNET" ]; then
    while ip rule del priority 5192 table "$TABLE" 2>/dev/null; do :; done
    ip rule add from "$SUBNET" table "$TABLE" priority 5192
fi

# Local subnets look up main table directly
ip rule del to 192.168.99.0/24 lookup main 2>/dev/null || true
ip rule add to 192.168.99.0/24 lookup main priority 5190

ip rule del to 192.168.88.0/24 lookup main 2>/dev/null || true
ip rule add to 192.168.88.0/24 lookup main priority 5190

# Fallback Wi-Fi rule if no slot-specific rule matched: route to slot 1 (table 201)
ip rule del from 192.168.99.0/24 table 201 2>/dev/null || true
ip rule add from 192.168.99.0/24 table 201 priority 5199

# Sing-box mark routing
ip rule del fwmark 0x400/0xff00 lookup "$TABLE" 2>/dev/null || true
ip rule add fwmark 0x400/0xff00 lookup "$TABLE" priority 5194

# Firewall rules for incoming established and outgoing forwarded traffic (idempotent)
nft delete rule inet fw4 input iifname "$dev" ct state { established, related } accept 2>/dev/null || true
nft delete rule inet fw4 forward iifname "$dev" ct state { established, related } accept 2>/dev/null || true
nft delete rule inet fw4 forward oifname "$dev" accept 2>/dev/null || true
nft delete rule inet fw4 srcnat oifname "$dev" masquerade 2>/dev/null || true

nft insert rule inet fw4 input iifname "$dev" ct state { established, related } accept 2>/dev/null || true
nft insert rule inet fw4 forward iifname "$dev" ct state { established, related } accept 2>/dev/null || true
nft insert rule inet fw4 forward oifname "$dev" accept 2>/dev/null || true
nft add rule inet fw4 srcnat oifname "$dev" masquerade 2>/dev/null || true

# Clamp TCP MSS to 1200
nft delete rule inet fw4 forward oifname "$dev" tcp flags syn tcp option maxseg size set 1200 2>/dev/null || true
nft insert rule inet fw4 forward oifname "$dev" tcp flags syn tcp option maxseg size set 1200 2>/dev/null || true

# DNS hijacking: redirect all DNS from VPN Wi-Fi to 1.1.1.1 (routed securely through VPN tunnel)
nft delete rule inet fw4 dstnat iifname "$WIFI_IF" meta nfproto ipv4 udp dport 53 dnat ip to 1.1.1.1:53 2>/dev/null || true
nft delete rule inet fw4 dstnat iifname "$WIFI_IF" meta nfproto ipv4 tcp dport 53 dnat ip to 1.1.1.1:53 2>/dev/null || true
nft insert rule inet fw4 dstnat iifname "$WIFI_IF" meta nfproto ipv4 udp dport 53 dnat ip to 1.1.1.1:53 2>/dev/null || true
nft insert rule inet fw4 dstnat iifname "$WIFI_IF" meta nfproto ipv4 tcp dport 53 dnat ip to 1.1.1.1:53 2>/dev/null || true

# Bypass table inet mmo_proxy completely for VPN Wi-Fi traffic
nft delete rule inet mmo_proxy prerouting iifname "$WIFI_IF" return 2>/dev/null || true
nft delete rule inet mmo_proxy forward iifname "$WIFI_IF" accept 2>/dev/null || true
nft delete rule inet mmo_proxy forward oifname "$WIFI_IF" accept 2>/dev/null || true
nft insert rule inet mmo_proxy prerouting iifname "$WIFI_IF" return 2>/dev/null || true
nft insert rule inet mmo_proxy forward iifname "$WIFI_IF" accept 2>/dev/null || true
nft insert rule inet mmo_proxy forward oifname "$WIFI_IF" accept 2>/dev/null || true

# Block IPv6 from VPN Wi-Fi to eliminate Vietnamese IPv6 leaks
nft delete rule inet fw4 forward iifname "$WIFI_IF" meta nfproto ipv6 drop 2>/dev/null || true
nft insert rule inet fw4 forward iifname "$WIFI_IF" meta nfproto ipv6 drop 2>/dev/null || true

# Reject QUIC (UDP 443) to force immediate zero-delay TCP fallback on mobile browsers
nft delete rule inet fw4 forward iifname "$WIFI_IF" udp dport 443 reject 2>/dev/null || true
nft insert rule inet fw4 forward iifname "$WIFI_IF" udp dport 443 reject 2>/dev/null || true

# Check public IP for this specific slot in background
(
    sleep 2
    PUB=$(curl -4 -k -s -m 5 --interface "$dev" https://1.1.1.1/cdn-cgi/trace 2>/dev/null | grep '^ip=' | cut -d= -f2)
    [ -z "$PUB" ] && PUB=$(curl -4 -s -m 5 --interface "$dev" https://api.ipify.org 2>/dev/null)
    if [ -n "$PUB" ]; then
        echo "$PUB" > "/tmp/evpn_public_ip_${SLOT}"
        [ "$SLOT" -eq 1 ] && echo "$PUB" > /tmp/evpn_public_ip
    fi
) &

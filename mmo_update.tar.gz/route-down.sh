#!/bin/sh
# /etc/mmo-proxy/expressvpn/route-down.sh

# Flush tables 200 through 208
for t in 200 201 202 203 204 205 206 207 208; do
    ip route flush table "$t" 2>/dev/null || true
    ip rule del fwmark 0x400/0xff00 lookup "$t" 2>/dev/null || true
done

# Remove IP rules for VPN Wi-Fi clients
while ip rule del priority 5192 2>/dev/null; do :; done
while ip rule del priority 5195 2>/dev/null; do :; done
while ip rule del priority 5199 2>/dev/null; do :; done
for i in $(seq 100 200); do
    ip rule del from "192.168.99.${i}" 2>/dev/null || true
done
ip rule del from 192.168.99.0/24 2>/dev/null || true
ip rule del to 192.168.99.0/24 lookup main 2>/dev/null || true
ip rule del to 192.168.88.0/24 lookup main 2>/dev/null || true

# Clean up status files
rm -f /tmp/evpn_public_ip* /tmp/evpn*.log /tmp/evpn_pool.json /tmp/evpn_devices.json /tmp/evpn_connecting

# Find VPN Wi-Fi device
WIFI_DEV=$(uci -q get wireless.vpn_wifi.device)
WIFI_IF="rax1"
[ "$WIFI_DEV" = "MT7981_1_1" ] && WIFI_IF="ra1"

# Clean up DNS hijack and proxy bypass rules
nft delete rule inet fw4 dstnat iifname "$WIFI_IF" meta nfproto ipv4 udp dport 53 dnat ip to 1.1.1.1:53 2>/dev/null || true
nft delete rule inet fw4 dstnat iifname "$WIFI_IF" meta nfproto ipv4 tcp dport 53 dnat ip to 1.1.1.1:53 2>/dev/null || true
nft delete rule inet fw4 forward iifname "$WIFI_IF" meta nfproto ipv6 drop 2>/dev/null || true
nft delete rule inet fw4 forward iifname "$WIFI_IF" udp dport 443 reject 2>/dev/null || true
nft delete rule inet mmo_proxy prerouting iifname "$WIFI_IF" return 2>/dev/null || true
nft delete rule inet mmo_proxy forward iifname "$WIFI_IF" accept 2>/dev/null || true
nft delete rule inet mmo_proxy forward oifname "$WIFI_IF" accept 2>/dev/null || true

# Clean up nftables rules for all possible tun_evpn interfaces
for slot in "" 1 2 3 4 5 6 7 8; do
    d="tun_evpn${slot}"
    nft delete rule inet fw4 input iifname "$d" ct state { established, related } accept 2>/dev/null || true
    nft delete rule inet fw4 forward iifname "$d" ct state { established, related } accept 2>/dev/null || true
    nft delete rule inet fw4 forward oifname "$d" accept 2>/dev/null || true
    nft delete rule inet fw4 srcnat oifname "$d" masquerade 2>/dev/null || true
    nft delete rule inet fw4 forward oifname "$d" tcp flags syn tcp option maxseg size set 1200 2>/dev/null || true
done

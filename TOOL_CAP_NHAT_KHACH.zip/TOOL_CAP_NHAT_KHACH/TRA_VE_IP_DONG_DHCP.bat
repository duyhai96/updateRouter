@echo off
title TRA VE IP DONG (DHCP) CHO MAY KHACH
cd /d "%~dp0"

:: Tu dong xin quyen Administrator neu chua co
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Dang yeu cau quyen Administrator...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo ==================================================================
echo              TRA VE IP DONG (DHCP) CHO MAY KHACH
echo ==================================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
"$adapters = Get-NetAdapter | Where-Object { $_.Virtual -ne $true }; " ^
"foreach ($ad in $adapters) { " ^
"    Write-Host ('[+] Tra ve DHCP cho card: ' + $ad.Name) -ForegroundColor Cyan; " ^
"    netsh interface ip set address $ad.Name dhcp | Out-Null; " ^
"    netsh interface ip set dns $ad.Name dhcp | Out-Null; " ^
"}"

ipconfig /renew >nul 2>&1

echo.
echo ==================================================================
echo DA TRA VE NHAN IP TU DONG (DHCP) THANH CONG!
echo ==================================================================
pause

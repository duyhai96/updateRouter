@echo off
setlocal enabledelayedexpansion
title CONG CU KET NOI VA CUU MANG ROUTER (192.168.88.1)
cd /d "%~dp0"

:: 1. Tu dong xin quyen Administrator neu chua co
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Dang yeu cau quyen Administrator de chinh card mang...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo ==================================================================
echo         CONG CU KET NOI & CUU MANG ROUTER (192.168.88.1)
echo ==================================================================
echo.

:: 2. Chay PowerShell de dat IP tinh va kiem tra ket noi
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
"$adapters = Get-NetAdapter | Where-Object { $_.Status -ne 'Disabled' -and $_.Virtual -ne $true }; " ^
"if (-not $adapters) { Write-Host 'KHONG TIM THAY CARD MANG NAO!' -ForegroundColor Red; exit }; " ^
"foreach ($ad in $adapters) { " ^
"    Write-Host ('[+] Dang xu ly card: ' + $ad.Name + ' (Trang thai: ' + $ad.Status + ')') -ForegroundColor Cyan; " ^
"    netsh interface ip set address $ad.Name static 192.168.88.50 255.255.255.0 192.168.88.1 | Out-Null; " ^
"    netsh interface ip set dns $ad.Name static 8.8.8.8 | Out-Null; " ^
"}; " ^
"Write-Host ''; " ^
"Write-Host '[+] Dang kiem tra ket noi toi Router 192.168.88.1...' -ForegroundColor Yellow; " ^
"$ping88 = Test-Connection -ComputerName 192.168.88.1 -Count 2 -Quiet; " ^
"if ($ping88) { " ^
"    Write-Host '======================================================' -ForegroundColor Green; " ^
"    Write-Host '  KET NOI THANH CONG TOI ROUTER 192.168.88.1!' -ForegroundColor Green; " ^
"    Write-Host '======================================================' -ForegroundColor Green; " ^
"    Start-Process 'http://192.168.88.1'; " ^
"} else { " ^
"    Write-Host '[!] Khong phan hoi o 192.168.88.1. Dang thu dai 192.168.1.1...' -ForegroundColor Yellow; " ^
"    foreach ($ad in $adapters) { " ^
"        netsh interface ip set address $ad.Name static 192.168.1.50 255.255.255.0 192.168.1.1 | Out-Null; " ^
"    }; " ^
"    $ping1 = Test-Connection -ComputerName 192.168.1.1 -Count 2 -Quiet; " ^
"    if ($ping1) { " ^
"        Write-Host '======================================================' -ForegroundColor Green; " ^
"        Write-Host '  ROUTER DANG O DAI 192.168.1.1! KET NOI THANH CONG!' -ForegroundColor Green; " ^
"        Write-Host '======================================================' -ForegroundColor Green; " ^
"        Start-Process 'http://192.168.1.1'; " ^
"    } else { " ^
"        Write-Host '======================================================' -ForegroundColor Red; " ^
"        Write-Host '  CANH BAO: KHONG PING DUOC CA 192.168.88.1 VA 1.1!' -ForegroundColor Red; " ^
"        Write-Host '  Nguyen nhan pho bien:' -ForegroundColor Yellow; " ^
"        Write-Host '  1. Day mang dang cam vao cong WAN (mau xanh) thay vi cong LAN tren router.' -ForegroundColor Yellow; " ^
"        Write-Host '  2. Router dang bi treo sau khi reboot -> Hay rut nguon dien Router cam lai.' -ForegroundColor Yellow; " ^
"        Write-Host '======================================================' -ForegroundColor Red; " ^
"    } " ^
"}"

echo.
echo Nhan phim bat ky de thoat...
pause >nul

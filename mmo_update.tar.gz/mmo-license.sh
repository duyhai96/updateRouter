#!/bin/sh
# /etc/mmo-proxy/bin/mmo-license
# Subscription and Hardware-bound License Management for MMO Router

CONF_DIR="/etc/mmo-proxy"
CONFIG_DIR="$CONF_DIR/config"
LICENSE_FILE="$CONFIG_DIR/license.json"
USED_KEYS_FILE="$CONFIG_DIR/used_keys.json"
SECRET_FILE="$CONFIG_DIR/license_secret"

DEFAULT_SECRET="MMO_ROUTERSOCKS_SECRET_SALT_2026_NR3053"

init_env() {
    mkdir -p "$CONFIG_DIR"
    if [ ! -f "$SECRET_FILE" ]; then
        echo "$DEFAULT_SECRET" > "$SECRET_FILE"
        chmod 600 "$SECRET_FILE"
    fi
    if [ ! -f "$USED_KEYS_FILE" ]; then
        echo "[]" > "$USED_KEYS_FILE"
    fi
}

get_hwid() {
    MAC=""
    for iface in eth0 br-lan ra0 rax0; do
        if [ -f "/sys/class/net/$iface/address" ]; then
            MAC=$(cat "/sys/class/net/$iface/address" 2>/dev/null)
            [ -n "$MAC" ] && break
        fi
    done
    if [ -z "$MAC" ]; then
        MAC="04:5F:A6:02:E1:BA"
    fi
    echo "$MAC" | tr -d ':' | tr 'a-z' 'A-Z'
}

get_secret() {
    if [ -f "$SECRET_FILE" ]; then
        cat "$SECRET_FILE" | tr -d '\r\n'
    else
        echo "$DEFAULT_SECRET"
    fi
}

calc_sig() {
    PAYLOAD="$1"
    SECRET=$(get_secret)
    echo -n "$PAYLOAD" | openssl dgst -sha256 -hmac "$SECRET" 2>/dev/null | sed 's/.*= //' | cut -c 1-8 | tr 'a-z' 'A-Z'
}

cmd_gen() {
    TARGET_HWID="$1"
    DAYS="$2"
    [ -z "$TARGET_HWID" ] && TARGET_HWID=$(get_hwid)
    [ -z "$DAYS" ] && DAYS=30

    TARGET_HWID=$(echo "$TARGET_HWID" | tr -d ':-' | tr 'a-z' 'A-Z')
    NONCE=$(hexdump -n 2 -e '2/1 "%02X"' /dev/urandom 2>/dev/null || printf "%04X" $((RANDOM % 65536)))
    PAYLOAD="${TARGET_HWID}:${DAYS}:${NONCE}"
    SIG=$(calc_sig "$PAYLOAD")
    KEY="WLK-${DAYS}D-${TARGET_HWID}-${NONCE}${SIG}"
    echo "$KEY"
}

pad_b64() {
    _s="$1"
    _m=$(( ${#_s} % 4 ))
    [ $_m -eq 2 ] && _s="${_s}=="
    [ $_m -eq 3 ] && _s="${_s}="
    echo "$_s"
}

cmd_activate() {
    RAW_KEY="$1"
    [ -z "$RAW_KEY" ] && { echo '{"status":"error","message":"Vui lòng nhập mã bản quyền (License Key)!"}'; exit 0; }

    KEY=$(echo "$RAW_KEY" | tr -d '\r\n ')
    
    # Check if this is the new ECDSA Asymmetric key format: WLK-<PAYLOAD_B64>.<SIG_B64> or WLK.<PAYLOAD_B64>.<SIG_B64>
    if echo "$KEY" | grep -q "^WLK[-.]" && echo "$KEY" | grep -q "\."; then
        PB64=$(echo "$KEY" | sed -e 's/^WLK[-.]//' | cut -d'.' -f1)
        SB64=$(echo "$KEY" | cut -d'.' -f2)

        if [ -z "$PB64" ] || [ -z "$SB64" ]; then
            echo '{"status":"error","message":"Định dạng mã bản quyền không hợp lệ!"}'
            exit 0
        fi

        P_STD=$(pad_b64 $(echo "$PB64" | tr "_-" "/+"))
        S_STD=$(pad_b64 $(echo "$SB64" | tr "_-" "/+"))

        TMP_P="/tmp/lic_payload.txt"
        TMP_S="/tmp/lic_sig.bin"
        echo -n "$P_STD" | openssl base64 -d -A > "$TMP_P" 2>/dev/null
        echo -n "$S_STD" | openssl base64 -d -A > "$TMP_S" 2>/dev/null

        PAYLOAD=$(cat "$TMP_P" 2>/dev/null)
        if [ -z "$PAYLOAD" ]; then
            rm -f "$TMP_P" "$TMP_S"
            echo '{"status":"error","message":"Mã kích hoạt bị lỗi dữ liệu!"}'
            exit 0
        fi

        # Payload format: HWID:DAYS:TIMESTAMP:NONCE
        KEY_HWID=$(echo "$PAYLOAD" | cut -d':' -f1)
        DAYS=$(echo "$PAYLOAD" | cut -d':' -f2)
        ISSUE_TS=$(echo "$PAYLOAD" | cut -d':' -f3)
        NONCE=$(echo "$PAYLOAD" | cut -d':' -f4)

        LOCAL_HWID=$(get_hwid)
        if [ "$KEY_HWID" != "$LOCAL_HWID" ]; then
            rm -f "$TMP_P" "$TMP_S"
            echo "{\"status\":\"error\",\"message\":\"Mã bản quyền này được cấp cho thiết bị khác ($KEY_HWID), không khớp với máy của bạn ($LOCAL_HWID)!\"}"
            exit 0
        fi

        PUBKEY="$CONFIG_DIR/license_public.pem"
        if [ ! -f "$PUBKEY" ]; then
            rm -f "$TMP_P" "$TMP_S"
            echo '{"status":"error","message":"Lỗi hệ thống: Thiếu khóa bảo mật Public Key trên Router!"}'
            exit 0
        fi

        if ! openssl dgst -sha256 -verify "$PUBKEY" -signature "$TMP_S" "$TMP_P" >/dev/null 2>&1; then
            rm -f "$TMP_P" "$TMP_S"
            echo '{"status":"error","message":"Chữ ký số không hợp lệ! Mã bản quyền đã bị chỉnh sửa hoặc giả mạo."}'
            exit 0
        fi
        rm -f "$TMP_P" "$TMP_S"

        # Anti-replay check
        init_env
        KEY_ID="${NONCE}_${ISSUE_TS}"
        if jq -e --arg k "$KEY_ID" '.[] | select(. == $k)' "$USED_KEYS_FILE" >/dev/null 2>&1; then
            echo '{"status":"error","message":"Mã bản quyền này đã được sử dụng trước đó!"}'
            exit 0
        fi
        jq --arg k "$KEY_ID" '. += [$k]' "$USED_KEYS_FILE" > "$USED_KEYS_FILE.tmp" && mv "$USED_KEYS_FILE.tmp" "$USED_KEYS_FILE"
    else
        # Legacy HMAC Format fallback: WLK-<DAYS>D-<HWID>-<NONCE(4)><SIG(8)>
        KEY_UPPER=$(echo "$KEY" | tr 'a-z' 'A-Z')
        PREFIX=$(echo "$KEY_UPPER" | cut -d'-' -f1)
        DAYS_STR=$(echo "$KEY_UPPER" | cut -d'-' -f2)
        KEY_HWID=$(echo "$KEY_UPPER" | cut -d'-' -f3)
        CODE=$(echo "$KEY_UPPER" | cut -d'-' -f4)

        if [ "$PREFIX" != "WLK" ] || [ -z "$DAYS_STR" ] || [ -z "$KEY_HWID" ] || [ ${#CODE} -ne 12 ]; then
            echo '{"status":"error","message":"Định dạng mã bản quyền không hợp lệ!"}'
            exit 0
        fi

        LOCAL_HWID=$(get_hwid)
        if [ "$KEY_HWID" != "$LOCAL_HWID" ]; then
            echo "{\"status\":\"error\",\"message\":\"Mã bản quyền này được cấp cho thiết bị khác ($KEY_HWID), không khớp với máy của bạn ($LOCAL_HWID)!\"}"
            exit 0
        fi

        DAYS=$(echo "$DAYS_STR" | sed 's/D$//')
        NONCE=$(echo "$CODE" | cut -c 1-4)
        SIG=$(echo "$CODE" | cut -c 5-12)
        EXPECTED_SIG=$(calc_sig "${LOCAL_HWID}:${DAYS}:${NONCE}")

        if [ "$SIG" != "$EXPECTED_SIG" ]; then
            echo '{"status":"error","message":"Mã bản quyền không đúng hoặc chữ ký bảo mật không khớp!"}'
            exit 0
        fi

        init_env
        if jq -e --arg c "$CODE" '.[] | select(. == $c)' "$USED_KEYS_FILE" >/dev/null 2>&1; then
            echo '{"status":"error","message":"Mã bản quyền này đã được sử dụng trước đó!"}'
            exit 0
        fi
        jq --arg c "$CODE" '. += [$c]' "$USED_KEYS_FILE" > "$USED_KEYS_FILE.tmp" && mv "$USED_KEYS_FILE.tmp" "$USED_KEYS_FILE"
    fi

    NOW=$(date +%s)
    CUR_EXP=0
    if [ -f "$LICENSE_FILE" ]; then
        CUR_EXP=$(jq -r '.expired_at // 0' "$LICENSE_FILE" 2>/dev/null)
    fi

    [ -z "$CUR_EXP" ] && CUR_EXP=0

    IS_LIFETIME=0
    if [ "$DAYS" = "0" ] || [ "$DAYS" = "lifetime" ] || [ "$DAYS" = "vinhvien" ] || [ "$DAYS" = "forever" ] || [ "$DAYS" = "99999" ] || [ "$DAYS" -ge 30000 ] 2>/dev/null; then
        IS_LIFETIME=1
        NEW_EXP=4102444800 # Year 2100
        EXP_DATE="Vĩnh viễn (Trọn đời)"
    else
        # If current license is still valid, add days to remaining time
        if [ "$CUR_EXP" -gt "$NOW" ] && [ "$CUR_EXP" -lt 4000000000 ]; then
            NEW_EXP=$((CUR_EXP + (DAYS * 86400)))
        else
            NEW_EXP=$((NOW + (DAYS * 86400)))
        fi
        EXP_DATE=$(date -d "@$NEW_EXP" "+%d/%m/%Y %H:%M:%S" 2>/dev/null || date "+%d/%m/%Y")
    fi

    # Record used key
    jq --arg c "$CODE" '. += [$c]' "$USED_KEYS_FILE" > "$USED_KEYS_FILE.tmp" && mv "$USED_KEYS_FILE.tmp" "$USED_KEYS_FILE"

    # Save license.json
    ACT_AT="$NOW"
    if [ -f "$LICENSE_FILE" ]; then
        OLD_ACT=$(jq -r '.activated_at // empty' "$LICENSE_FILE" 2>/dev/null)
        [ -n "$OLD_ACT" ] && [ "$OLD_ACT" -ne 0 ] && ACT_AT="$OLD_ACT"
    fi

    jq -n \
       --arg hwid "$LOCAL_HWID" \
       --arg key "$KEY" \
       --argjson act "$ACT_AT" \
       --argjson exp "$NEW_EXP" \
       --arg days "$DAYS" \
       --argjson lifetime "$IS_LIFETIME" \
       '{hardware_id: $hwid, license_key: $key, activated_at: $act, expired_at: $exp, days_added: $days, is_lifetime: ($lifetime == 1), status: "active"}' \
       > "$LICENSE_FILE"

    # Enforce firewall immediately (unlock)
    cmd_enforce force

    if [ "$IS_LIFETIME" = "1" ] || [ "$IS_LIFETIME" = "true" ]; then
        echo "{\"status\":\"ok\",\"message\":\"🎉 Kích hoạt thành công! Bản quyền VĨNH VIỄN (TRỌN ĐỜI).\",\"expired_at\":$NEW_EXP,\"expired_date\":\"$EXP_DATE\",\"is_lifetime\":true}"
    else
        echo "{\"status\":\"ok\",\"message\":\"Kích hoạt thành công! Đã gia hạn thêm $DAYS ngày. Hạn mới đến: $EXP_DATE\",\"expired_at\":$NEW_EXP,\"expired_date\":\"$EXP_DATE\",\"is_lifetime\":false}"
    fi
}

cmd_info() {
    init_env
    LOCAL_HWID=$(get_hwid)
    NOW=$(date +%s)

    if [ ! -f "$LICENSE_FILE" ]; then
        # Default initial trial: 30 days from first start if not exists
        EXP=$((NOW + 2592000))
        KEY=$(cmd_gen "$LOCAL_HWID" 30)
        jq -n \
           --arg hwid "$LOCAL_HWID" \
           --arg key "$KEY" \
           --argjson act "$NOW" \
           --argjson exp "$EXP" \
           '{hardware_id: $hwid, license_key: $key, activated_at: $act, expired_at: $exp, is_lifetime: false, status: "active"}' \
           > "$LICENSE_FILE"
    fi

    EXP=$(jq -r '.expired_at // 0' "$LICENSE_FILE" 2>/dev/null)
    ACT=$(jq -r '.activated_at // 0' "$LICENSE_FILE" 2>/dev/null)
    CUR_KEY=$(jq -r '.license_key // ""' "$LICENSE_FILE" 2>/dev/null)
    IS_LIFETIME=$(jq -r '.is_lifetime // false' "$LICENSE_FILE" 2>/dev/null)

    [ -z "$EXP" ] && EXP=0
    [ -z "$ACT" ] && ACT=$NOW

    if [ "$IS_LIFETIME" = "true" ] || [ "$EXP" -ge 4000000000 ] 2>/dev/null; then
        REM=999999999
        DAYS_LEFT=99999
        HOURS_LEFT=0
        MINS_LEFT=0
        IS_EXP=0
        STATUS="active"
        EXP_DATE="Vĩnh viễn (Trọn đời)"
        IS_LIFETIME_BOOL=true
    else
        IS_LIFETIME_BOOL=false
        REM=$((EXP - NOW))
        IS_EXP=0
        STATUS="active"
        if [ "$REM" -le 0 ]; then
            REM=0
            IS_EXP=1
            STATUS="expired"
        fi

        DAYS_LEFT=$((REM / 86400))
        HOURS_LEFT=$(((REM % 86400) / 3600))
        MINS_LEFT=$(((REM % 3600) / 60))
        EXP_DATE=$(date -d "@$EXP" "+%d/%m/%Y %H:%M:%S" 2>/dev/null || echo "-")
    fi

    ACT_DATE=$(date -d "@$ACT" "+%d/%m/%Y %H:%M:%S" 2>/dev/null || echo "-")

    jq -n \
       --arg hwid "$LOCAL_HWID" \
       --arg key "$CUR_KEY" \
       --argjson act "$ACT" \
       --arg act_date "$ACT_DATE" \
       --argjson exp "$EXP" \
       --arg exp_date "$EXP_DATE" \
       --argjson rem "$REM" \
       --argjson days "$DAYS_LEFT" \
       --argjson hours "$HOURS_LEFT" \
       --argjson mins "$MINS_LEFT" \
       --argjson is_exp "$IS_EXP" \
       --argjson is_lifetime "$IS_LIFETIME_BOOL" \
       --arg status "$STATUS" \
       '{
           hardware_id: $hwid,
           license_key: $key,
           activated_at: $act,
           activated_date: $act_date,
           expired_at: $exp,
           expired_date: $exp_date,
           seconds_remaining: $rem,
           days_remaining: $days,
           hours_remaining: $hours,
           minutes_remaining: $mins,
           is_expired: ($is_exp == 1),
           is_lifetime: $is_lifetime,
           status: $status
       }'
}

cmd_enforce() {
    init_env
    NOW=$(date +%s)
    EXP=0
    LOCAL_HWID=$(get_hwid)
    CUR_KEY=""
    if [ -f "$LICENSE_FILE" ]; then
        EXP=$(jq -r '.expired_at // 0' "$LICENSE_FILE" 2>/dev/null)
        IS_LIFETIME=$(jq -r '.is_lifetime // false' "$LICENSE_FILE" 2>/dev/null)
        CUR_KEY=$(jq -r '.license_key // ""' "$LICENSE_FILE" 2>/dev/null)
    fi

    # Cryptographic anti-tamper check: Verify ECDSA or HMAC signature against local HWID
    KEY_VALID=0
    if [ -n "$CUR_KEY" ]; then
        if echo "$CUR_KEY" | grep -q "^WLK[-.]" && echo "$CUR_KEY" | grep -q "\."; then
            # ECDSA Asymmetric Signature Validation
            PB64=$(echo "$CUR_KEY" | sed -e 's/^WLK[-.]//' | cut -d'.' -f1)
            SB64=$(echo "$CUR_KEY" | cut -d'.' -f2)
            PUBKEY="$CONFIG_DIR/license_public.pem"
            if [ -n "$PB64" ] && [ -n "$SB64" ] && [ -f "$PUBKEY" ]; then
                P_STD=$(pad_b64 $(echo "$PB64" | tr "_-" "/+"))
                S_STD=$(pad_b64 $(echo "$SB64" | tr "_-" "/+"))
                TMP_P="/tmp/lic_chk_p.txt"
                TMP_S="/tmp/lic_chk_s.bin"
                echo -n "$P_STD" | openssl base64 -d -A > "$TMP_P" 2>/dev/null
                echo -n "$S_STD" | openssl base64 -d -A > "$TMP_S" 2>/dev/null
                PAYLOAD=$(cat "$TMP_P" 2>/dev/null)
                KEY_HWID=$(echo "$PAYLOAD" | cut -d':' -f1)
                if [ "$KEY_HWID" = "$LOCAL_HWID" ]; then
                    if openssl dgst -sha256 -verify "$PUBKEY" -signature "$TMP_S" "$TMP_P" >/dev/null 2>&1; then
                        KEY_VALID=1
                    fi
                fi
                rm -f "$TMP_P" "$TMP_S"
            fi
        else
            # Legacy HMAC Key Validation
            PREFIX=$(echo "$CUR_KEY" | cut -d'-' -f1)
            DAYS_STR=$(echo "$CUR_KEY" | cut -d'-' -f2)
            KEY_HWID=$(echo "$CUR_KEY" | cut -d'-' -f3)
            CODE=$(echo "$CUR_KEY" | cut -d'-' -f4)
            if [ "$PREFIX" = "WLK" ] && [ -n "$DAYS_STR" ] && [ "$KEY_HWID" = "$LOCAL_HWID" ] && [ ${#CODE} -eq 12 ]; then
                DAYS=$(echo "$DAYS_STR" | sed 's/D$//')
                NONCE=$(echo "$CODE" | cut -c 1-4)
                SIG=$(echo "$CODE" | cut -c 5-12)
                EXPECTED_SIG=$(calc_sig "${LOCAL_HWID}:${DAYS}:${NONCE}")
                if [ "$SIG" = "$EXPECTED_SIG" ]; then
                    KEY_VALID=1
                fi
            fi
        fi
    fi

    CURRENT_STATE="active"
    if [ "$KEY_VALID" -eq 0 ]; then
        CURRENT_STATE="expired"
    elif [ "$IS_LIFETIME" != "true" ]; then
        [ "$NOW" -ge "$EXP" ] && CURRENT_STATE="expired"
    fi

    PREV_STATE=""
    [ -f "/tmp/mmo_license_state" ] && PREV_STATE=$(cat "/tmp/mmo_license_state" 2>/dev/null)

    # Only run actions if state actually changed or force requested
    if [ "$CURRENT_STATE" != "$PREV_STATE" ] || [ "$1" = "force" ]; then
        echo "$CURRENT_STATE" > "/tmp/mmo_license_state"
        if [ "$CURRENT_STATE" = "expired" ]; then
            # Expired: Fallback to Direct WAN (Stop sing-box, clean tproxy)
            nft delete table inet mmo_proxy 2>/dev/null || true
            ip rule del fwmark 0x100/0xff00 lookup mmo_proxy 2>/dev/null || true
            ip route flush table mmo_proxy 2>/dev/null || true
            killall sing-box 2>/dev/null || true
        else
            # Active: apply normal proxy engine
            if [ -x "/etc/mmo-proxy/bin/mmo-core" ]; then
                /etc/mmo-proxy/bin/mmo-core apply >/dev/null 2>&1 &
            fi
        fi
    fi
}

cmd_expire() {
    init_env
    NOW=$(date +%s)
    PAST_TIME=$((NOW - 3600))
    jq --argjson p "$PAST_TIME" '.expired_at = $p | .status = "expired"' "$LICENSE_FILE" > "$LICENSE_FILE.tmp" && mv "$LICENSE_FILE.tmp" "$LICENSE_FILE"
    cmd_enforce force
    echo '{"status":"ok","message":"Đã đưa thời hạn về HẾT HẠN! Đã chuyển sang mạng gốc Direct WAN."}'
}

cmd_set_lifetime() {
    init_env
    LOCAL_HWID=$(get_hwid)
    NOW=$(date +%s)
    NEW_EXP=4102444800
    KEY="LIFETIME-PERMANENT-ACTIVATED"

    jq -n \
       --arg hwid "$LOCAL_HWID" \
       --arg key "$KEY" \
       --argjson act "$NOW" \
       --argjson exp "$NEW_EXP" \
       '{hardware_id: $hwid, license_key: $key, activated_at: $act, expired_at: $exp, days_added: 99999, is_lifetime: true, status: "active"}' \
       > "$LICENSE_FILE"

    cmd_enforce force
    echo '{"status":"ok","message":"Đã thiết lập bản quyền VĨNH VIỄN (TRỌN ĐỜI) thành công!"}'
}

case "$1" in
    info) cmd_info ;;
    activate) shift; cmd_activate "$@" ;;
    check|enforce) cmd_enforce ;;
    gen|generate) shift; cmd_gen "$@" ;;
    set-lifetime) cmd_set_lifetime ;;
    expire) cmd_expire ;;
    reset) cmd_reset ;;
    *) echo "Usage: $0 {info|activate <KEY>|set-lifetime|check|gen [HWID] [DAYS]|expire|reset}" ;;
esac


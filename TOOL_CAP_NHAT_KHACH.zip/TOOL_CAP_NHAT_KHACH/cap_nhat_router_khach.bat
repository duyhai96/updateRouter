@echo off
title NANG CAP ROUTER KHACH HANG
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0cap_nhat_router_khach.ps1"
if errorlevel 1 pause

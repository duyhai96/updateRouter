@echo off
title CAI DAT VA NANG CAP ROUTER TU DONG
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer.ps1"
if errorlevel 1 pause

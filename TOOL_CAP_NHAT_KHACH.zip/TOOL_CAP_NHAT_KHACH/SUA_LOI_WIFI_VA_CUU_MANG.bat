@echo off
chcp 65001 >nul
title SUA LOI WIFI VA CUU MANG ROUTER (192.168.88.1)
cd /d "%~dp0"

echo ==============================================================================
echo        ĐANG SỬA LỖI WI-FI VÀ KHÔI PHỤC MẠNG INTERNET CHO ROUTER...
echo ==============================================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0cuu_wifi.ps1"

echo.
pause

@echo off
title XOA PROXY - TRA VE MANG GOC 100%
cd /d "%~dp0"

echo ==================================================================
echo         CONG CU XOA SACH PROXY - DUA VE MANG GOC CHO KHACH
echo ==================================================================
echo.

:: 1. Xoa sach proxy tren Windows may khach
echo [1/3] Xoa sach System Proxy tren Windows...
netsh winhttp reset proxy >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v ProxyEnable /t REG_DWORD /d 0 /f >nul 2>&1
ipconfig /flushdns >nul 2>&1

:: 2. Xoa proxy tren Router (thu ca 192.168.88.1 va 192.168.1.1)
echo [2/3] Ra lenh Router xoa toan bo Proxy va dua tat ca ve Mang Goc...

set "REMOTE_CMD=echo '{\"mappings\":[]}' > /etc/mmo-proxy/config/mappings.json ; [ -f /etc/mmo-proxy/config/settings.json ] && jq '.auto_proxy.enable = false | .security.fail_closed = false | .security.kill_switch = false' /etc/mmo-proxy/config/settings.json > /tmp/s.json && mv /tmp/s.json /etc/mmo-proxy/config/settings.json ; [ -x /etc/mmo-proxy/bin/mmo-core ] && /etc/mmo-proxy/bin/mmo-core apply ; /etc/init.d/dnsmasq restart ; echo THANH_CONG"

ssh -o ConnectTimeout=4 -o StrictHostKeyChecking=no -o UserKnownHostsFile=NUL root@192.168.88.1 "%REMOTE_CMD%" 2>nul
if %errorlevel% neq 0 (
    ssh -o ConnectTimeout=4 -o StrictHostKeyChecking=no -o UserKnownHostsFile=NUL root@192.168.1.1 "%REMOTE_CMD%" 2>nul
)

echo.
echo [3/3] Hoan tat! Toan bo thiet bi da duoc dua ve Mang Goc 100%.
echo ==================================================================
echo Ban co the mo trinh duyet vao: http://192.168.88.1
echo Nhan phim bat ky de thoat...
pause >nul

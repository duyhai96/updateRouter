@echo off
setlocal enabledelayedexpansion
title DUA MAY NAY VE MANG GOC 100% (KHONG DI QUA PROXY)
cd /d "%~dp0"

echo ==================================================================
echo         CONG CU DUA MAY KHACH VE MANG GOC (VINH VIEN)
echo ==================================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
"$ad = Get-NetAdapter | Where-Object { $_.Status -eq 'Up' -and $_.Virtual -ne $true } | Select-Object -First 1; " ^
"if (-not $ad) { $ad = Get-NetAdapter | Where-Object { $_.Virtual -ne $true } | Select-Object -First 1 }; " ^
"if (-not $ad) { Write-Host 'KHONG TIM THAY CARD MANG!' -ForegroundColor Red; exit }; " ^
"$mac = $ad.MacAddress.ToLower().Replace('-', ':'); " ^
"Write-Host ('[1/3] Phat hien MAC may khach: ' + $mac + ' (Card: ' + $ad.Name + ')') -ForegroundColor Cyan; " ^
"Write-Host '[2/3] Xoa sach System Proxy tren Windows...' -ForegroundColor Cyan; " ^
"netsh winhttp reset proxy | Out-Null; " ^
"Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name ProxyEnable -Value 0 -ErrorAction SilentlyContinue; " ^
"Clear-DnsClientCache -ErrorAction SilentlyContinue; " ^
"Write-Host '[3/3] Dang gui lenh sang Router de dua MAC nay vao MANG GOC...' -ForegroundColor Cyan; " ^
"$remoteCmd = @'
MAC=\"' + $mac + '\"
mkdir -p /etc/mmo-proxy/config
[ ! -f /etc/mmo-proxy/config/mappings.json ] && echo '{\"mappings\":[]}' > /etc/mmo-proxy/config/mappings.json
[ ! -f /etc/mmo-proxy/config/settings.json ] && echo '{\"direct_wan_devices\":[],\"auto_proxy\":{\"enable\":false}}' > /etc/mmo-proxy/config/settings.json
jq --arg m \"$MAC\" '.mappings = [((.mappings // [])[]) | select((.mac | ascii_downcase) != $m)]' /etc/mmo-proxy/config/mappings.json > /tmp/m.json 2>/dev/null && mv /tmp/m.json /etc/mmo-proxy/config/mappings.json
jq --arg m \"$MAC\" '.direct_wan_devices = ([.direct_wan_devices[]? | ascii_downcase] + [$m]) | unique | .auto_proxy.enable = false' /etc/mmo-proxy/config/settings.json > /tmp/s.json 2>/dev/null && mv /tmp/s.json /etc/mmo-proxy/config/settings.json
[ -x /etc/mmo-proxy/bin/mmo-core ] && /etc/mmo-proxy/bin/mmo-core apply >/dev/null 2>&1
conntrack -F >/dev/null 2>&1 || true
echo DONE_DIRECT
'@; " ^
"$sshArgs = @('-o', 'ConnectTimeout=4', '-o', 'StrictHostKeyChecking=no', '-o', 'UserKnownHostsFile=NUL'); " ^
"$done = $false; " ^
"foreach ($rIp in @('192.168.88.1', '192.168.1.1')) { " ^
"    try { " ^
"        $res = ssh @sshArgs ('root@' + $rIp) $remoteCmd 2>$null; " ^
"        if ($res -like '*DONE_DIRECT*') { " ^
"            Write-Host ('  -> Da nap vao Router thanh cong tai IP: ' + $rIp) -ForegroundColor Green; " ^
"            $done = $true; " ^
"            break; " ^
"        } " ^
"    } catch {} " ^
"}; " ^
"Write-Host ''; " ^
"if ($done) { " ^
"    Write-Host '======================================================' -ForegroundColor Green; " ^
"    Write-Host '  🎉 THANH CONG: MAY NAY DA DUOC CHO DI MANG GOC 100%!' -ForegroundColor Green; " ^
"    Write-Host '  Tu gio khi cam day LAN, may se dung mang Internet truc tiep' -ForegroundColor Green; " ^
"    Write-Host '  vinh vien khong bao gio bi dinh proxy nua!' -ForegroundColor Green; " ^
"    Write-Host '======================================================' -ForegroundColor Green; " ^
"} else { " ^
"    Write-Host '======================================================' -ForegroundColor Yellow; " ^
"    Write-Host '  Chua the ket noi SSH sang Router qua 192.168.88.1 hoac 1.1.' -ForegroundColor Yellow; " ^
"    Write-Host '  Hay dam bao ban da vao duoc WebUI router va dat IP tinh.' -ForegroundColor Yellow; " ^
"    Write-Host '======================================================' -ForegroundColor Yellow; " ^
"}"

echo.
echo Nhan phim bat ky de thoat...
pause >nul

#!/bin/sh
# /etc/mmo-proxy/bin/mmo-core

CONF_DIR="/etc/mmo-proxy"
export ENABLE_DEPRECATED_WIREGUARD_OUTBOUND=true
CONFIG_PROXIES="$CONF_DIR/config/proxies.json"
CONFIG_VPN="$CONF_DIR/config/vpn.json"
CONFIG_MAPPINGS="$CONF_DIR/config/mappings.json"
CONFIG_SETTINGS="$CONF_DIR/config/settings.json"
SINGBOX_CONF="$CONF_DIR/singbox/config.json"
NFT_RULES="$CONF_DIR/firewall/rules.nft"

sync_and_clean_mappings() {
    [ -f "$CONFIG_MAPPINGS" ] || return 0
    # Clean mappings: remove empty or 192.168.99.x (ExpressVPN Wi-Fi) entries
    jq '
      .mappings = [
        ((.mappings // [])[]) |
        select(.mac != null and .mac != "") |
        .mac = (.mac | ascii_downcase) |
        select(.ip == null or ((.ip | startswith("192.168.99.")) | not))
      ] | unique_by(.mac)
    ' "$CONFIG_MAPPINGS" > "$CONFIG_MAPPINGS.tmp" 2>/dev/null && [ -s "$CONFIG_MAPPINGS.tmp" ] && mv "$CONFIG_MAPPINGS.tmp" "$CONFIG_MAPPINGS"

    # Now update any missing, fe80:: or invalid IPs with active DHCP/ARP leases
    LAN_IP=$(uci -q get network.lan.ipaddr 2>/dev/null || ip -4 addr show dev br-lan 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1 | head -n1 || echo "192.168.88.1")
    LAN_SUBNET=$(echo "$LAN_IP" | cut -d. -f1-3)
    [ -z "$LAN_SUBNET" ] && LAN_SUBNET="192.168.88"

    for mac in $(jq -r '.mappings[]?.mac' "$CONFIG_MAPPINGS" 2>/dev/null); do
        [ -z "$mac" ] && continue
        cur_ip=$(jq -r --arg m "$mac" '.mappings[]? | select(.mac == $m) | .ip // empty' "$CONFIG_MAPPINGS" 2>/dev/null)
        if ! echo "$cur_ip" | grep -qE "^${LAN_SUBNET}\.[0-9]+$"; then
            real_ip=$(grep -i "$mac" /tmp/dhcp.leases 2>/dev/null | awk '{print $3}' | grep -E "^${LAN_SUBNET}\." | head -n1)
            [ -z "$real_ip" ] && real_ip=$(grep -i " $mac " /proc/net/arp 2>/dev/null | awk '{print $1}' | grep -E "^${LAN_SUBNET}\." | head -n1)
            [ -z "$real_ip" ] && real_ip=$(ip -4 neigh show 2>/dev/null | grep -i "$mac" | awk '{print $1}' | grep -E "^${LAN_SUBNET}\." | head -n1)
            if [ -n "$real_ip" ]; then
                jq --arg m "$mac" --arg ip "$real_ip" '
                  .mappings = [((.mappings // [])[]) | if .mac == $m then .ip = $ip else . end]
                ' "$CONFIG_MAPPINGS" > "$CONFIG_MAPPINGS.tmp" 2>/dev/null && [ -s "$CONFIG_MAPPINGS.tmp" ] && mv "$CONFIG_MAPPINGS.tmp" "$CONFIG_MAPPINGS"
            fi
        fi
    done
}

generate_singbox() {
    [ -f "$CONFIG_VPN" ] || echo '{"vpns":[]}' > "$CONFIG_VPN"

    # Dynamic IPs file (empty default; sing-box sniffs SNI in <1ms)
    RESOLVED_IPS_FILE="/tmp/mmo_resolved_ips.json"
    echo "[]" > "$RESOLVED_IPS_FILE"

    jq -n \
      --slurpfile proxies "$CONFIG_PROXIES" \
      --slurpfile vpns "$CONFIG_VPN" \
      --slurpfile mappings "$CONFIG_MAPPINGS" \
      --slurpfile settings "$CONFIG_SETTINGS" \
      --slurpfile dynamic_ips "$RESOLVED_IPS_FILE" '
      def parse_proxy(raw; idx):
        (raw | ltrimstr("socks5://") | ltrimstr("socks://") | ltrimstr("http://") | ltrimstr("https://")) as $clean |
        (if (raw | startswith("http://") or startswith("https://")) then "http" else "socks5" end) as $proto |
        (if ($clean | contains("@")) then
          ($clean | split("@")) as $at_parts |
          ($at_parts[0] | split(":")) as $auth_parts |
          ($at_parts[1] | split(":")) as $host_parts |
          {
            type: $proto,
            host: $host_parts[0],
            port: ($host_parts[1] | split("/")[0] | try tonumber catch 1080),
            user: ($auth_parts[0] // ""),
            pass: ($auth_parts[1:] | join(":"))
          }
        else
          ($clean | split(":")) as $parts |
          {
            type: $proto,
            host: $parts[0],
            port: ($parts[1] | split("/")[0] | try tonumber catch 1080),
            user: ($parts[2] // ""),
            pass: ($parts[3:] | join(":"))
          }
        end) as $p |
        $p + {
          name: ("Auto_" + ($p.host | split(".")[0]) + "_" + ($p.port | tostring) + "_" + ((idx + 1) | tostring)),
          enabled: true
        };

      ($settings[0].tproxy_base_port // 15000) as $base_port |
      (
        ($proxies[0].proxies // []) +
        [
          range(0; ($settings[0].auto_proxy.proxy_list // []) | length) as $i |
          parse_proxy($settings[0].auto_proxy.proxy_list[$i]; $i)
        ]
      ) as $plist |
      ($vpns[0].vpns // []) as $vlist |
      ($settings[0].direct_wan_devices // [] | map(. | ascii_downcase)) as $direct_macs |
      # All mapped devices (excluding hardcoded direct_wan_devices, case-insensitive)
      [ ($mappings[0].mappings // [])[] | select((.mac | ascii_downcase) as $m | ($direct_macs | index($m)) == null) ] as $all_mapped |
      # Valid proxy names from both proxy list and VPN list
      ([ ($plist // [])[] | select(.enabled != false) | .name ] +
       [ ($vpns[0].vpns // [])[] | select(.enabled != false) | .name ]) as $valid_proxy_names |
      ($valid_proxy_names[0] // null) as $default_proxy |
      # mlist: devices with a valid proxy assigned, or fallback to first valid proxy
      [
        $all_mapped[] |
        select(.proxy != null and .proxy != "" and .proxy != "DIRECT") |
        . as $dev |
        .proxy = (if ($valid_proxy_names | index($dev.proxy)) != null then $dev.proxy else $default_proxy end) |
        select(.proxy != null) |
        .mac = (.mac | ascii_downcase)
      ] | unique_by(.mac) as $mlist |
      # mlist_direct: devices in mappings but no valid proxy yet → treat as DIRECT (not blocked)
      [ $all_mapped[] | select(.proxy == null or .proxy == "" or .proxy == "DIRECT" or ($default_proxy == null)) ] as $mlist_direct |
       ($settings[0].domain_routing.mode // "all_proxy") as $routing_mode |
       ($settings[0].domain_routing.proxy_domains // []) as $proxy_domain_list |
       ($settings[0].domain_routing.bypass_list // []) as $bypass_list |
      ($settings[0].domain_routing.block_list // []) as $block_list |
      (if $settings[0].security.disable_udp == true then true else false end) as $disable_udp |
      (if $settings[0].security.webrtc_shield == false then false else true end) as $webrtc_shield |
      ($settings[0].security.webrtc_mode // "block") as $webrtc_mode |
      (if $settings[0].security.disable_ipv6_leak == false then false else true end) as $disable_ipv6 |

      # Pure jq function to check if string is IP without Oniguruma regex
      def is_ip:
        if contains(":") then
          true
        else
          (split("/")[0] | split(".") | (length == 4 and (.[0] | try tonumber catch null != null)))
        end;

      def lstrip_star:
        if startswith("*.") then .[2:]
        elif startswith("*") then .[1:]
        elif startswith(".") then .[1:]
        else .
        end;

      # Extract domains vs IPs for proxy only (clean leading *. or * if present)
      ($dynamic_ips[0] // []) as $resolved_ips |
      [ $proxy_domain_list[] | select(is_ip | not) | lstrip_star ] as $proxy_domains |
      ([ $proxy_domain_list[] | select(is_ip) ] + $resolved_ips | unique) as $proxy_ips |

      # Extract domains vs IPs for bypass (clean leading *. or * if present)
      [ $bypass_list[] | select(is_ip | not) | lstrip_star ] as $bypass_domains |
      [ $bypass_list[] | select(is_ip) ] as $bypass_ips |

      # Extract domains vs IPs for block (clean leading *. or * if present)
      [ $block_list[] | select(is_ip | not) | lstrip_star ] as $block_domains |
      [ $block_list[] | select(is_ip) ] as $block_ips |

      # DNS servers
      [
        {
          tag: "dns_direct",
          type: "udp",
          server: "1.1.1.1"
        },
        {
          tag: "dns_direct_fallback",
          type: "udp",
          server: "8.8.8.8"
        }
      ] + [
        $mlist[] |
        . as $m |
        ([ $vlist[] | select(.name == $m.proxy and .enabled != false) ][0]) as $vpn_target |
        {
          tag: ("dns_" + ($m.mac | split(":") | join(""))),
          type: (if $vpn_target != null then "udp" else "https" end),
          server: (if $vpn_target != null and $vpn_target.dns and $vpn_target.dns != "" then ($vpn_target.dns | split(",")[0] | split(" ") | join("")) else "1.1.1.1" end),
          domain_resolver: "dns_direct",
          detour: $m.proxy
        }
      ] as $dns_servers |

      # DNS rules (In proxy_only mode, only proxy_domains query proxy DNS; in all_proxy mode, bypass_domains query dns_direct)
      (if $routing_mode == "proxy_only" then
        (if ($proxy_domains | length) > 0 then
          [
            $mlist[] |
            {
              inbound: [("tproxy_" + .mac)],
              domain_suffix: $proxy_domains,
              server: ("dns_" + (.mac | split(":") | join("")))
            }
          ]
        else [] end) +
        [ { server: "dns_direct" } ]
      else
        (if ($bypass_domains | length) > 0 then [ { domain_suffix: $bypass_domains, server: "dns_direct" } ] else [] end) +
        [
          $mlist[] |
          {
            inbound: [("tproxy_" + .mac)],
            server: ("dns_" + (.mac | split(":") | join("")))
          }
        ]
      end) as $dns_rules |

      # Inbounds
      [range(0; $mlist | length)] as $indices |
      [
        $indices[] |
        {
          type: "tproxy",
          tag: ("tproxy_" + $mlist[.].mac),
          listen: "::",
          listen_port: ($base_port + . + 1),
          sniff: true,
          sniff_override_destination: true,
          sniff_timeout: "2s"
        }
      ] as $inbounds |

      # Outbounds
      [
        { type: "direct", tag: "direct" },
        { type: "block", tag: "block" }
      ] + [
        ($plist | unique_by(.name))[] | select(.enabled != false) |
        if .type == "http" then
          {
            type: "http",
            tag: .name,
            server: .host,
            server_port: (.port | tonumber)
          } + (if .user and .user != "" then { username: .user, password: (.pass // "") } else {} end)
        elif .type == "shadowsocks" then
          {
            type: "shadowsocks",
            tag: .name,
            server: .host,
            server_port: (.port | tonumber),
            method: (.method // "aes-256-gcm"),
            password: (.pass // "")
          }
        else
          {
            type: "socks",
            tag: .name,
            server: .host,
            server_port: (.port | tonumber)
          } + (if .user and .user != "" then { username: .user, password: (.pass // "") } else {} end)
        end
      ] + [
        ($vlist | unique_by(.name))[] | select(.enabled != false) |
        {
          type: "wireguard",
          tag: .name,
          server: .server,
          server_port: (.server_port | tonumber),
          local_address: (if (.local_address | type) == "array" then .local_address else [(.local_address // "10.0.0.2/32")] end),
          private_key: .private_key,
          peer_public_key: .peer_public_key
        } + (if .pre_shared_key and .pre_shared_key != "" then { pre_shared_key: .pre_shared_key } else {} end)
          + (if .reserved and (.reserved | length) > 0 then { reserved: .reserved } else {} end)
          + (if .mtu and (.mtu | tonumber) > 0 then { mtu: (.mtu | tonumber) } else {} end)
      ] as $outbounds |

      # Build route rules
      (
        # 1. DNS hijack
        [ { port: 53, action: "hijack-dns" } ] +
        # 2. Local router management and private LAN bypass: ALWAYS DIRECT!
        [
          {
            ip_cidr: ["127.0.0.0/8", "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "224.0.0.0/4", "255.255.255.255/32"],
            outbound: "direct"
          }
        ] +
        # 3. WebRTC Shield (RFC 8828): ALWAYS block STUN/TURN & QUIC for proxied devices to prevent IP leak
        (if $webrtc_shield then
          [
            { network: "udp", port: [443, 3478, 5349, 19302, 19303, 19304, 19305, 19306, 19307, 19308, 19309], action: "reject" },
            { network: "tcp", port: [3478, 5349], action: "reject" }
          ]
        else [] end) +
        # 3. Block list
        (if ($block_domains | length) > 0 then [ { domain_suffix: $block_domains, outbound: "block" } ] else [] end) +
        (if ($block_ips | length) > 0 then [ { ip_cidr: $block_ips, outbound: "block" } ] else [] end) +
        # 4. Mode-specific routing:
        (if $routing_mode == "proxy_only" then
          # Proxy only matching domains/IPs for each mapped device:
          [
            $mlist[] |
            . as $dev |
            (
              (if ($proxy_domains | length) > 0 then [ { inbound: [("tproxy_" + $dev.mac)], domain_suffix: $proxy_domains, outbound: $dev.proxy } ] else [] end) +
              (if ($proxy_ips | length) > 0 then [ { inbound: [("tproxy_" + $dev.mac)], ip_cidr: $proxy_ips, outbound: $dev.proxy } ] else [] end)
            )[]
          ] +
          # Any other traffic from mapped devices goes direct:
          [ { outbound: "direct" } ]
        else
          # All proxy mode (Default): Bypass list goes direct
          (if ($bypass_domains | length) > 0 then [ { domain_suffix: $bypass_domains, outbound: "direct" } ] else [] end) +
          (if ($bypass_ips | length) > 0 then [ { ip_cidr: $bypass_ips, outbound: "direct" } ] else [] end) +
          # Inbound to proxy mappings
          [
            $mlist[] |
            {
              inbound: [("tproxy_" + .mac)],
              outbound: .proxy
            }
          ]
        end) +
        # 5. Disable UDP if proxy has no UDP
        (if $disable_udp then [ { network: "udp", action: "reject" } ] else [] end)
      ) as $rules |

      {
        log: {
          level: "info",
          timestamp: true
        },
        dns: {
          servers: $dns_servers,
          rules: $dns_rules,
          final: "dns_direct",
          strategy: (if $disable_ipv6 then "ipv4_only" else "prefer_ipv4" end)
        },
        inbounds: $inbounds,
        outbounds: $outbounds,
        route: {
          default_domain_resolver: "dns_direct",
          rules: $rules,
          auto_detect_interface: true
        }
      }
    ' > "$SINGBOX_CONF.tmp"
}

generate_firewall() {
    LAN_IP=$(uci -q get network.lan.ipaddr 2>/dev/null || ip -4 addr show dev br-lan 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1 | head -n1 || echo "192.168.88.1")
    LAN_SUBNET=$(echo "$LAN_IP" | cut -d. -f1-3)
    [ -z "$LAN_SUBNET" ] && LAN_SUBNET="192.168.88"

    cat << NFT_HEADER > "$NFT_RULES.tmp"
table inet mmo_proxy
flush table inet mmo_proxy

table inet mmo_proxy {
    chain prerouting {
        type filter hook prerouting priority mangle; policy accept;

        # Clamp TCP MSS to 1360 on all incoming packets to prevent packet drops and fragmentation
        tcp flags syn tcp option maxseg size set 1360

        # DHCP bypass
        udp dport { 67, 68 } return

        # Local router management and LAN bypass (SSH, LuCI, MMO WebUI, DNS, ICMP): ALWAYS DIRECT
        ip daddr { 127.0.0.0/8, 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 224.0.0.0/4, 255.255.255.255 } tcp dport { 22, 53, 80, 443, 8080, 8443, 9090 } return
        ip daddr { 127.0.0.0/8, 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 224.0.0.0/4, 255.255.255.255 } udp dport { 53, 67, 68 } return
        icmp type echo-request return
        icmpv6 type echo-request return
NFT_HEADER

    # Whitelist Direct WAN Devices (Exception devices like admin PC)
    DIRECT_MACS=$(jq -r '.direct_wan_devices // [] | .[]' "$CONFIG_SETTINGS" 2>/dev/null | tr 'A-Z' 'a-z')
    DIRECT_IPS=""
    for dmac in $DIRECT_MACS; do
        dip=$(grep -i "$dmac" /tmp/dhcp.leases 2>/dev/null | awk '{print $3}' | head -n1)
        [ -z "$dip" ] && dip=$(grep -i "$dmac" /proc/net/arp 2>/dev/null | awk '{print $1}' | head -n1)
        [ -z "$dip" ] && dip=$(ip neigh show 2>/dev/null | grep -i "$dmac" | awk '{print $1}' | head -n1)
        [ -z "$dip" ] && dip=$(uci show dhcp 2>/dev/null | grep -i "$dmac" -B1 | grep "\.ip=" | head -n1 | cut -d"'" -f2)
        [ -z "$dip" ] && [ -f "$CONF_DIR/config/device_ips.json" ] && dip=$(jq -r --arg mac "$dmac" '.[$mac] // empty' "$CONF_DIR/config/device_ips.json" 2>/dev/null)
        if [ -n "$dip" ] && echo "$dip" && echo "$dip" | grep -qE "^${LAN_SUBNET}\.[0-9]+$"; then
            DIRECT_IPS="$DIRECT_IPS $dip"
        fi
    done

    # 1. Direct WAN bypass by MAC address (Permanent link-layer bypass, works instantly after boot before DHCP leases)
    if [ -n "$DIRECT_MACS" ]; then
        DMAC_LIST=$(echo $DIRECT_MACS | sed 's/ /, /g')
        echo "        # Direct WAN devices bypass by MAC (Whitelist)" >> "$NFT_RULES.tmp"
        echo "        ether saddr { $DMAC_LIST } meta mark set 0x200 accept" >> "$NFT_RULES.tmp"
    fi

    # 2. Direct WAN bypass by IP address
    if [ -n "$DIRECT_IPS" ]; then
        DIP_LIST=$(echo $DIRECT_IPS | sed 's/ /, /g')
        echo "        # Direct WAN devices bypass by IP (Whitelist)" >> "$NFT_RULES.tmp"
        echo "        ip saddr { $DIP_LIST } meta mark set 0x200 accept" >> "$NFT_RULES.tmp"
    fi

    cat << NFT_LOCAL >> "$NFT_RULES.tmp"
        # Router's own DNS must be handled directly by dnsmasq (never tproxy to sing-box to prevent socket collision)
        meta l4proto { tcp, udp } ip daddr { 127.0.0.0/8, 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16 } th dport 53 return

        # Private LAN bypass (except external DNS port 53 which gets hijacked to proxy)
        meta l4proto { tcp, udp } th dport != 53 ip daddr { 127.0.0.0/8, 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 224.0.0.0/4, 255.255.255.255 } return

NFT_LOCAL

    # Client Isolation: Block client-to-client traffic except to Whitelist devices
    CLIENT_ISOLATION=$(jq -r '.security.client_isolation // false' "$CONFIG_SETTINGS")
    if [ "$CLIENT_ISOLATION" = "true" ]; then
        if [ -n "$DIRECT_MACS" ]; then
            DMAC_LIST=$(echo $DIRECT_MACS | sed 's/ /, /g')
            echo "        # Client Isolation: Allow traffic to Whitelist devices by MAC" >> "$NFT_RULES.tmp"
            echo "        ether daddr { $DMAC_LIST } accept" >> "$NFT_RULES.tmp"
        fi
        if [ -n "$DIRECT_IPS" ]; then
            DIP_LIST=$(echo $DIRECT_IPS | sed 's/ /, /g')
            # Allow clients to talk to Whitelist PC, but drop traffic between non-whitelist clients
            echo "        # Client Isolation: Drop cross-client LAN traffic" >> "$NFT_RULES.tmp"
            echo "        ip daddr ${LAN_SUBNET}.0/24 ip daddr != { $LAN_IP, 192.168.88.1, 192.168.1.1, $DIP_LIST } drop" >> "$NFT_RULES.tmp"
        else
            echo "        # Client Isolation: Drop cross-client LAN traffic" >> "$NFT_RULES.tmp"
            echo "        ip daddr ${LAN_SUBNET}.0/24 ip daddr != { $LAN_IP, 192.168.88.1, 192.168.1.1 } drop" >> "$NFT_RULES.tmp"
        fi
    fi

    # TPROXY rules for mapped clients (excluding Direct WAN whitelist devices)
    BASE_PORT=$(jq -r '.tproxy_base_port // 15000' "$CONFIG_SETTINGS")

    # Extract the EXACT same list of devices that sing-box uses for inbounds, along with their 1-based index
    MLIST_DATA=$(jq -r '
      def parse_proxy(raw; idx):
        (raw | ltrimstr("socks5://") | ltrimstr("socks://") | ltrimstr("http://") | ltrimstr("https://")) as $clean |
        (if (raw | startswith("http://") or startswith("https://")) then "http" else "socks5" end) as $proto |
        (if ($clean | contains("@")) then
          ($clean | split("@")) as $at_parts |
          ($at_parts[0] | split(":")) as $auth_parts |
          ($at_parts[1] | split(":")) as $host_parts |
          {
            type: $proto,
            host: $host_parts[0],
            port: ($host_parts[1] | split("/")[0] | try tonumber catch 1080),
            user: ($auth_parts[0] // ""),
            pass: ($auth_parts[1:] | join(":"))
          }
        else
          ($clean | split(":")) as $parts |
          {
            type: $proto,
            host: $parts[0],
            port: ($parts[1] | split("/")[0] | try tonumber catch 1080),
            user: ($parts[2] // ""),
            pass: ($parts[3:] | join(":"))
          }
        end) as $p |
        $p + {
          name: ("Auto_" + ($p.host | split(".")[0]) + "_" + ($p.port | tostring) + "_" + ((idx + 1) | tostring)),
          enabled: true
        };

      ($settings[0].direct_wan_devices // [] | map(. | ascii_downcase)) as $direct_macs |
      (
        [ ($proxies[0].proxies // [])[] | select(.enabled != false) | .name ] +
        [ ($vpns[0].vpns // [])[] | select(.enabled != false) | .name ] +
        [
          range(0; ($settings[0].auto_proxy.proxy_list // []) | length) as $i |
          parse_proxy($settings[0].auto_proxy.proxy_list[$i]; $i) | .name
        ]
      ) as $valid_proxy_names |
      ($valid_proxy_names[0] // null) as $default_proxy |
      [
        ($mappings[0].mappings // [])[] |
        select((.mac | ascii_downcase) as $m | ($direct_macs | index($m)) == null) |
        select(.proxy != null and .proxy != "" and .proxy != "DIRECT") |
        . as $dev |
        .proxy = (if ($valid_proxy_names | index($dev.proxy)) != null then $dev.proxy else $default_proxy end) |
        select(.proxy != null) |
        .mac = (.mac | ascii_downcase)
      ] |
      unique_by(.mac) |
      to_entries[] | "\(.key + 1)|\(.value.mac)|\(.value.ip // "")|\(.value.proxy)"
    ' "$CONFIG_SETTINGS" --slurpfile settings "$CONFIG_SETTINGS" --slurpfile proxies "$CONFIG_PROXIES" --slurpfile vpns "$CONFIG_VPN" --slurpfile mappings "$CONFIG_MAPPINGS" 2>/dev/null)

    MAPPED_IPS=""
    TPROXY_RULES_ACC=""
    MLIST_TMP="/tmp/mmo_mlist.tmp"
    echo "$MLIST_DATA" > "$MLIST_TMP"

    while IFS='|' read -r p_idx p_mac p_ip p_proxy; do
        [ -z "$p_idx" ] && continue
        PORT=$((BASE_PORT + p_idx))
        p_mac=$(echo "$p_mac" | tr 'A-Z' 'a-z')

        # Auto-resolve IPv4 if missing, contains '?' or is IPv6
        if ! echo "$p_ip" | grep -qE "^${LAN_SUBNET}\.[0-9]+$"; then
            _found_ip=$(grep -i "$p_mac" /tmp/dhcp.leases 2>/dev/null | awk '{print $3}' | grep -E "^${LAN_SUBNET}\." | head -n1)
            [ -z "$_found_ip" ] && _found_ip=$(grep -i " $p_mac " /proc/net/arp 2>/dev/null | awk '{print $1}' | grep -E "^${LAN_SUBNET}\." | head -n1)
            [ -z "$_found_ip" ] && _found_ip=$(ip -4 neigh show 2>/dev/null | grep -i "$p_mac" | awk '{print $1}' | grep -E "^${LAN_SUBNET}\." | head -n1)
            [ -n "$_found_ip" ] && p_ip="$_found_ip"
        fi

        # If IP is valid, add ip saddr rule and track in MAPPED_IPS
        if echo "$p_ip" | grep -qE "^${LAN_SUBNET}\.[0-9]+$"; then
            TPROXY_RULES_ACC="${TPROXY_RULES_ACC}        ip saddr $p_ip meta l4proto { tcp, udp } tproxy ip to :$PORT meta mark set 0x100 accept\n"
            MAPPED_IPS="$MAPPED_IPS $p_ip"
        fi

        # Always add ether saddr rule to guarantee routing even if IP changes before DHCP lease updates
        TPROXY_RULES_ACC="${TPROXY_RULES_ACC}        ether saddr $p_mac meta l4proto { tcp, udp } tproxy ip to :$PORT meta mark set 0x100 accept\n"
    done < "$MLIST_TMP"
    rm -f "$MLIST_TMP"

    MAPPED_IPS=$(echo $MAPPED_IPS | xargs)

    # WebRTC Shield in Kernel (PREROUTING) - Immediate drop/reject of STUN & QUIC before TPROXY
    WEBRTC_SHIELD=$(jq -r 'if .security.webrtc_shield == false then "false" else "true" end' "$CONFIG_SETTINGS")
    if [ "$WEBRTC_SHIELD" = "true" ] && [ -n "$MAPPED_IPS" ]; then
        MIP_LIST=$(echo $MAPPED_IPS | sed 's/ /, /g')
        echo "        # WebRTC Shield (RFC 8828): Immediate kernel rejection of STUN & QUIC before TPROXY" >> "$NFT_RULES.tmp"
        echo "        ip saddr { $MIP_LIST } udp dport { 443, 3478, 5349, 19302-19309 } counter reject with icmpx type port-unreachable" >> "$NFT_RULES.tmp"
        echo "        ip saddr { $MIP_LIST } tcp dport { 3478, 5349 } counter reject with tcp reset" >> "$NFT_RULES.tmp"
    fi

    # Emit synchronized TPROXY rules
    printf "$TPROXY_RULES_ACC" >> "$NFT_RULES.tmp"


    cat << 'NFT_MID' >> "$NFT_RULES.tmp"
    }

    chain forward {
        type filter hook forward priority filter; policy accept;

        # Automatically clamp TCP MSS to 1360 for all traffic to prevent drops on PPPoE/fiber/tunnels
        tcp flags syn tcp option maxseg size set 1360

        # Established & related connections always pass
        ct state { established, related } accept

        # Bypass dedicated VPN Wi-Fi interfaces
        iifname { "rax1", "ra1" } accept
        oifname { "rax1", "ra1" } accept

        # Direct WAN whitelist devices marked 0x200 in prerouting (by MAC or IP)
        meta mark 0x200 counter accept
NFT_MID

    # Direct WAN devices: explicitly allow forwarding by IP in both directions
    if [ -n "$DIRECT_IPS" ]; then
        DIP_LIST=$(echo $DIRECT_IPS | sed 's/ /, /g')
        echo "        # Direct WAN devices: explicitly allow forwarding by IP" >> "$NFT_RULES.tmp"
        echo "        ip saddr { $DIP_LIST } counter accept" >> "$NFT_RULES.tmp"
        echo "        ip daddr { $DIP_LIST } counter accept" >> "$NFT_RULES.tmp"
    fi

    ROUTING_MODE=$(jq -r '.domain_routing.mode // "all_proxy"' "$CONFIG_SETTINGS")
    KILL_SWITCH=$(jq -r 'if .security.kill_switch == true then "true" else "false" end' "$CONFIG_SETTINGS")
    if [ "$KILL_SWITCH" = "true" ] && [ "$ROUTING_MODE" != "proxy_only" ] && [ -n "$MAPPED_IPS" ]; then
        IP_LIST=$(echo $MAPPED_IPS | sed 's/ /, /g')
        echo "        # Kill switch: Block direct WAN forward for mapped clients" >> "$NFT_RULES.tmp"
        echo "        ip saddr { $IP_LIST } oifname \"wan*\" counter drop" >> "$NFT_RULES.tmp"
    fi

    # WebRTC Leak Shield in Kernel - ONLY applied to clients with proxies mapped
    if [ "$WEBRTC_SHIELD" = "true" ] && [ -n "$MAPPED_IPS" ]; then
        MIP_LIST=$(echo $MAPPED_IPS | sed 's/ /, /g')
        echo "        # WebRTC Shield (RFC 8828): Block STUN and QUIC egress for proxied clients" >> "$NFT_RULES.tmp"
        echo "        ip saddr { $MIP_LIST } udp dport { 443, 3478, 5349, 19302-19309 } counter reject with icmpx type port-unreachable" >> "$NFT_RULES.tmp"
        echo "        ip saddr { $MIP_LIST } tcp dport { 3478, 5349 } counter reject with tcp reset" >> "$NFT_RULES.tmp"
    fi

    # Block unmapped devices only if strict fail_closed explicitly enabled in UI
    STRICT_FAIL_CLOSED=$(jq -r '.security.fail_closed // false' "$CONFIG_SETTINGS")
    if [ "$STRICT_FAIL_CLOSED" = "true" ]; then
        if [ -n "$DIRECT_IPS" ]; then
            DIP_LIST=$(echo $DIRECT_IPS | sed 's/ /, /g')
            echo "        # Fail-closed: Block all unassigned devices except Direct WAN whitelist" >> "$NFT_RULES.tmp"
            echo "        ip saddr != { $LAN_IP, $DIP_LIST } oifname \"wan*\" counter drop" >> "$NFT_RULES.tmp"
        else
            echo "        # Fail-closed: Block all unassigned devices except router itself" >> "$NFT_RULES.tmp"
            echo "        ip saddr != $LAN_IP oifname \"wan*\" counter drop" >> "$NFT_RULES.tmp"
        fi
    fi

    DISABLE_IPV6=$(jq -r 'if .security.disable_ipv6_leak == false then "false" else "true" end' "$CONFIG_SETTINGS")
    if [ "$DISABLE_IPV6" = "true" ]; then
        echo "        # IPv6 leak protection: unconditionally reject all IPv6 transit to prevent client leak" >> "$NFT_RULES.tmp"
        echo "        meta nfproto ipv6 counter reject with icmpv6 type addr-unreachable" >> "$NFT_RULES.tmp"
    fi

    # DPI Evasion & Stealth: Clamp TCP MSS to 1360 bytes to prevent fragmentation and DPI fingerprinting
    DPI_STEALTH=$(jq -r 'if .security.dpi_stealth == false then "false" else "true" end' "$CONFIG_SETTINGS")
    if [ "$DPI_STEALTH" = "true" ]; then
        echo "        # DPI Evasion: Clamp TCP MSS to 1360" >> "$NFT_RULES.tmp"
        echo "        tcp flags syn tcp option maxseg size set 1360" >> "$NFT_RULES.tmp"
    fi

    cat << NFT_FOOTER >> "$NFT_RULES.tmp"
    }

    chain postrouting {
        type nat hook postrouting priority srcnat; policy accept;
        # Direct WAN & unmapped clients: Tu dong NAT Masquerade ra ngoai cong WAN
        ip saddr ${LAN_SUBNET}.0/24 oifname != "br-lan" counter masquerade
        # ExpressVPN Router subnet 192.168.132.0/24: Masquerade de ExpressVPN tra ve dung HN router
        ip daddr 192.168.132.0/24 counter masquerade
    }
}
NFT_FOOTER
}

check_auto_proxy() {
    RESET_MODE="${1:-0}"
    AUTO_ENABLE=$(jq -r '.auto_proxy.enable // false' "$CONFIG_SETTINGS")
    [ "$AUTO_ENABLE" != "true" ] && return 0

    PROXY_COUNT=$(jq '.auto_proxy.proxy_list | length' "$CONFIG_SETTINGS" 2>/dev/null || echo 0)
    [ "$PROXY_COUNT" -le 0 ] && return 0

    ALLOW_DUP=$(jq -r '.auto_proxy.allow_duplicate // true' "$CONFIG_SETTINGS")
    DIRECT_MACS=$(jq -r '.direct_wan_devices // [] | .[]' "$CONFIG_SETTINGS" 2>/dev/null | tr 'A-Z' 'a-z')

    # Ensure mappings and proxies files are valid JSON
    [ ! -s "$CONFIG_MAPPINGS" ] || ! jq -e . "$CONFIG_MAPPINGS" >/dev/null 2>&1 && echo '{"mappings":[]}' > "$CONFIG_MAPPINGS"
    [ ! -s "$CONFIG_PROXIES" ] || ! jq -e . "$CONFIG_PROXIES" >/dev/null 2>&1 && echo '{"proxies":[]}' > "$CONFIG_PROXIES"

    # 1. Parse and register all proxies in auto_proxy.proxy_list into proxies.json in a single fast pass
    cat "$CONFIG_SETTINGS" | jq '
      def parse_proxy(raw; idx):
        (raw | ltrimstr("socks5://") | ltrimstr("socks://") | ltrimstr("http://") | ltrimstr("https://")) as $clean |
        (if (raw | startswith("http://") or startswith("https://")) then "http" else "socks5" end) as $proto |
        (if ($clean | contains("@")) then
          ($clean | split("@")) as $at_parts |
          ($at_parts[0] | split(":")) as $auth_parts |
          ($at_parts[1] | split(":")) as $host_parts |
          {
            type: $proto,
            host: $host_parts[0],
            port: ($host_parts[1] | split("/")[0] | try tonumber catch 1080),
            user: ($auth_parts[0] // ""),
            pass: ($auth_parts[1:] | join(":"))
          }
        else
          ($clean | split(":")) as $parts |
          {
            type: $proto,
            host: $parts[0],
            port: ($parts[1] | split("/")[0] | try tonumber catch 1080),
            user: ($parts[2] // ""),
            pass: ($parts[3:] | join(":"))
          }
        end) as $p |
        $p + {
          name: ("Auto_" + ($p.host | split(".")[0]) + "_" + ($p.port | tostring) + "_" + ((idx + 1) | tostring)),
          enabled: true
        };

      .proxies = [
        range(0; (.auto_proxy.proxy_list // []) | length) as $i |
        parse_proxy(.auto_proxy.proxy_list[$i]; $i)
      ]
    ' > /tmp/auto_proxies_built.json 2>/dev/null

    if [ -s /tmp/auto_proxies_built.json ] && jq -e '.proxies | length > 0' /tmp/auto_proxies_built.json >/dev/null 2>&1; then
        jq '{proxies: .proxies}' /tmp/auto_proxies_built.json > "$CONFIG_PROXIES.tmp" && mv "$CONFIG_PROXIES.tmp" "$CONFIG_PROXIES"
    fi

    # 2. If reset mode: clear existing proxy mappings for non-whitelist devices to re-distribute freshly
    if [ "$RESET_MODE" = "reset" ] || [ "$RESET_MODE" = "1" ]; then
        echo "[*] Auto-Proxy: Resetting existing mappings for auto distribution..."
        jq --argjson direct "$(jq '.direct_wan_devices // []' "$CONFIG_SETTINGS" 2>/dev/null || echo '[]')" '
          .mappings = [((.mappings // [])[]) | select(.mac as $m | ($direct | map(. | ascii_downcase) | index($m | ascii_downcase)) != null)]
        ' "$CONFIG_MAPPINGS" > "$CONFIG_MAPPINGS.tmp" && [ -s "$CONFIG_MAPPINGS.tmp" ] && mv "$CONFIG_MAPPINGS.tmp" "$CONFIG_MAPPINGS"
    fi

    # 2b. Collect ACTUALLY CONNECTED active stations (Wi-Fi + reachable LAN)
    ACTIVE_STA="/tmp/mmo_core_active_sta.tmp"
    rm -f "$ACTIVE_STA"
    touch "$ACTIVE_STA"

    # Scan iwinfo
    for wdev in $(iwinfo 2>/dev/null | grep -oE '^[a-zA-Z0-9_-]+'); do
        for smac in $(iwinfo "$wdev" assoclist 2>/dev/null | grep -oE '([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}'); do
            echo "$smac" | tr 'A-Z' 'a-z' >> "$ACTIVE_STA"
        done
    done

    # Scan hostapd_cli sockets
    for sock in /var/run/hostapd/*; do
        [ -S "$sock" ] || continue
        sname=$(basename "$sock")
        for smac in $(hostapd_cli -p /var/run/hostapd -i "$sname" all_sta 2>/dev/null | grep -oE '([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}'); do
            echo "$smac" | tr 'A-Z' 'a-z' >> "$ACTIVE_STA"
        done
    done

    # Fallback scan iw dev
    for wdev in $(iw dev 2>/dev/null | grep 'Interface' | awk '{print $2}'); do
        for smac in $(iw dev "$wdev" station dump 2>/dev/null | grep -oE '([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}'); do
            echo "$smac" | tr 'A-Z' 'a-z' >> "$ACTIVE_STA"
        done
    done

    # Note: iwpriv get_mac_table skipped on MT7981 to prevent kernel segfault

    # Scan active LAN stations (Ethernet cabled devices)
    if [ -f /proc/net/arp ]; then
        while read ip hw flags mac mask dev; do
            [ "$ip" = "IP" ] || [ "$flags" = "0x0" ] && continue
            [ -z "$mac" ] || [ "$mac" = "00:00:00:00:00:00" ] && continue
            [ "$ip" = "192.168.88.1" ] && continue
            echo "$ip" | grep -q "^192\.168\.88\." || continue
            mac=$(echo "$mac" | tr 'A-Z' 'a-z')
            if ! grep -qx "$mac" "$ACTIVE_STA"; then
                _nud=$(ip neigh show dev br-lan "$ip" 2>/dev/null | awk '{print $NF}')
                if [ "$_nud" != "FAILED" ] && [ "$_nud" != "INCOMPLETE" ]; then
                    echo "$mac" >> "$ACTIVE_STA"
                fi
            fi
        done < /proc/net/arp
    fi

    # Exclude VPN wifi subnet (192.168.99.x)
    if [ -f /tmp/dhcp.leases ]; then
        while read ts mac ip host client_id; do
            echo "$ip" | grep -q "^192\.168\.99\." || continue
            mac=$(echo "$mac" | tr 'A-Z' 'a-z')
            sed -i "/^$mac$/d" "$ACTIVE_STA" 2>/dev/null
        done < /tmp/dhcp.leases
    fi

    NEED_APPLY=0

    # 3. Discover ACTUALLY ACTIVE devices needing proxy (only from ACTIVE_STA)
    ALL_DEVS_TMP="/tmp/mmo_all_detected_devs.tmp"
    rm -f "$ALL_DEVS_TMP"
    touch "$ALL_DEVS_TMP"

    while read -r amac; do
        [ -z "$amac" ] && continue
        aip=""
        ahost=""
        if [ -f /tmp/dhcp.leases ]; then
            dhcp_line=$(grep -i "^[^ ]* *$amac " /tmp/dhcp.leases 2>/dev/null | head -n1)
            if [ -n "$dhcp_line" ]; then
                aip=$(echo "$dhcp_line" | awk '{print $3}')
                ahost=$(echo "$dhcp_line" | awk '{print $4}')
            fi
        fi
        if [ -z "$aip" ] && [ -f /proc/net/arp ]; then
            aip=$(grep -i " $amac " /proc/net/arp 2>/dev/null | awk '{print $1}' | head -n1)
        fi
        [ -z "$aip" ] && aip="192.168.88.?"
        [ -z "$ahost" ] || [ "$ahost" = "*" ] && ahost="Device_$(echo "$amac" | cut -d: -f5,6 | tr -d :)"
        echo "$amac|$aip|$ahost" >> "$ALL_DEVS_TMP"
    done < "$ACTIVE_STA"
    rm -f "$ACTIVE_STA"

    # 4. Assign proxies to unassigned devices
    PROXIES_AVAIL=$(jq -r '(.proxies // [])[] | select(.enabled != false) | .name' "$CONFIG_PROXIES" 2>/dev/null)
    AVAIL_COUNT=$(echo "$PROXIES_AVAIL" | grep -c .)
    [ "$AVAIL_COUNT" -eq 0 ] && return 0

    CURRENT_MAPPED_COUNT=$(jq --argjson direct "$(jq '.direct_wan_devices // []' "$CONFIG_SETTINGS" 2>/dev/null || echo '[]')" '
      [((.mappings // [])[]) | select(.mac as $m | ($direct | map(. | ascii_downcase) | index($m | ascii_downcase)) == null and .proxy != "DIRECT")] | length
    ' "$CONFIG_MAPPINGS" 2>/dev/null)
    [ -z "$CURRENT_MAPPED_COUNT" ] || [ "$CURRENT_MAPPED_COUNT" = "null" ] && CURRENT_MAPPED_COUNT=0

    p_idx="$CURRENT_MAPPED_COUNT"

    while IFS='|' read -r d_mac d_ip d_host; do
        [ -z "$d_mac" ] || [ -z "$d_ip" ] && continue

        # Check if in Direct Whitelist
        IS_DIR=0
        for dmac in $DIRECT_MACS; do
            [ "$dmac" = "$d_mac" ] && IS_DIR=1 && break
        done
        [ "$IS_DIR" -eq 1 ] && continue

        # Check if already mapped (including DIRECT)
        ALREADY_P=$(jq -r --arg m "$d_mac" '((.mappings // [])[]) | select((.mac | ascii_downcase) == ($m | ascii_downcase)) | .proxy // empty' "$CONFIG_MAPPINGS" 2>/dev/null)
        if [ -n "$ALREADY_P" ]; then
            continue
        fi

        if [ "$p_idx" -lt "$AVAIL_COUNT" ] || [ "$ALLOW_DUP" = "true" ]; then
            actual_idx=$(( (p_idx % AVAIL_COUNT) + 1 ))
            PNAME=$(echo "$PROXIES_AVAIL" | sed -n "${actual_idx}p")
            
            d_name="$d_host"
            [ -z "$d_name" ] || [ "$d_name" = "*" ] && d_name="Device_$(echo "$d_mac" | cut -d: -f5,6 | tr -d :)"

            jq --arg mac "$d_mac" --arg ip "$d_ip" --arg name "$d_name" --arg proxy "$PNAME" '
              .mappings = [((.mappings // [])[]) | select((.mac | ascii_downcase) != ($mac | ascii_downcase))] + [{mac: $mac, ip: $ip, name: $name, proxy: $proxy}]
            ' "$CONFIG_MAPPINGS" > "$CONFIG_MAPPINGS.tmp" && mv "$CONFIG_MAPPINGS.tmp" "$CONFIG_MAPPINGS"

            NEED_APPLY=1
            p_idx=$((p_idx + 1))
        fi
    done < "$ALL_DEVS_TMP"

    rm -f "$ALL_DEVS_TMP"

    if [ "$NEED_APPLY" -eq 1 ] || [ "$RESET_MODE" = "reset" ] || [ "$RESET_MODE" = "1" ]; then
        apply
    fi
}

apply() {
    LOCK_FILE="/tmp/mmo_apply.lock"
    if [ -f "$LOCK_FILE" ]; then
        LOCK_PID=$(cat "$LOCK_FILE" 2>/dev/null)
        if [ -n "$LOCK_PID" ] && kill -0 "$LOCK_PID" 2>/dev/null; then
            for _wait in 1 2 3 4 5; do
                sleep 0.5
                kill -0 "$LOCK_PID" 2>/dev/null || break
            done
        fi
    fi
    echo "$$" > "$LOCK_FILE"
    trap 'rm -f "$LOCK_FILE"' EXIT INT TERM

    # Check if license is expired -> Auto activate lifetime to prevent shutting off proxies
    IS_EXPIRED=0
    if [ -f "$CONF_DIR/config/license.json" ]; then
        EXP=$(jq -r '.expired_at // 0' "$CONF_DIR/config/license.json" 2>/dev/null)
        IS_LT=$(jq -r '.is_lifetime // false' "$CONF_DIR/config/license.json" 2>/dev/null)
        NOW=$(date +%s)
        if [ "$IS_LT" != "true" ] && [ -n "$EXP" ] && [ "$EXP" -ne 0 ] && [ "$NOW" -ge "$EXP" ]; then
            IS_EXPIRED=1
        fi
    fi

    if [ "$IS_EXPIRED" -eq 1 ] || [ ! -f "$CONF_DIR/config/license.json" ]; then
        if [ -x "$CONF_DIR/bin/mmo-license" ]; then
            $CONF_DIR/bin/mmo-license set-lifetime >/dev/null 2>&1 || true
            IS_EXPIRED=0
        fi
    fi

    sync_and_clean_mappings

    echo "[*] Generating sing-box config..."
    generate_singbox
    
    NEED_RESTART_SB=0
    if [ ! -f "$SINGBOX_CONF" ] || ! cmp -s "$SINGBOX_CONF.tmp" "$SINGBOX_CONF"; then
        echo "[*] Checking new sing-box configuration syntax..."
        if sing-box check -c "$SINGBOX_CONF.tmp" >/dev/null 2>&1; then
            mv "$SINGBOX_CONF.tmp" "$SINGBOX_CONF"
            NEED_RESTART_SB=1
        else
            echo "[!] Sing-box config syntax error! Keeping existing config."
            rm -f "$SINGBOX_CONF.tmp"
        fi
    else
        rm -f "$SINGBOX_CONF.tmp"
    fi

    echo "[*] Generating nftables rules..."
    generate_firewall

    NEED_RELOAD_NFT=0
    if [ ! -f "$NFT_RULES" ] || ! cmp -s "$NFT_RULES.tmp" "$NFT_RULES"; then
        echo "[*] Checking nftables syntax..."
        if nft -c -f "$NFT_RULES.tmp" >/dev/null 2>&1; then
            mv "$NFT_RULES.tmp" "$NFT_RULES"
            NEED_RELOAD_NFT=1
        else
            echo "[!] Nftables rules syntax error! Keeping existing rules."
            rm -f "$NFT_RULES.tmp"
        fi
    else
        rm -f "$NFT_RULES.tmp"
    fi

    # Apply nftables rules atomically (always reload to guarantee in-kernel state matches disk)
    echo "[*] Applying nftables table inet mmo_proxy atomically..."
    nft -f "$NFT_RULES" 2>/dev/null || nft -f "$NFT_RULES"

    # 1. Dam bao bat IP forwarding trong nhan Linux va luu vao sysctl.conf
    sysctl -w net.ipv4.ip_forward=1 >/dev/null 2>&1 || true
    sysctl -w net.ipv4.conf.all.forwarding=1 >/dev/null 2>&1 || true
    sysctl -w net.ipv4.conf.default.forwarding=1 >/dev/null 2>&1 || true
    mkdir -p /etc/sysctl.d 2>/dev/null
    echo "net.ipv4.ip_forward = 1" > /etc/sysctl.d/99-ipforward.conf 2>/dev/null || true

    # 2. Tu sua chua (Self-healing) Firewall OpenWrt: dam bao luon co forwarding lan -> wan va masq
    FW_DIRTY=0
    if ! uci show firewall 2>/dev/null | grep -q "dest='wan'"; then
        uci add firewall forwarding >/dev/null 2>&1 || true
        uci set firewall.@forwarding[-1].src='lan' 2>/dev/null || true
        uci set firewall.@forwarding[-1].dest='wan' 2>/dev/null || true
        FW_DIRTY=1
    fi
    for zi in 0 1 2 3; do
        zn=$(uci -q get firewall.@zone[$zi].name 2>/dev/null)
        if [ "$zn" = "wan" ]; then
            if [ "$(uci -q get firewall.@zone[$zi].masq 2>/dev/null)" != "1" ]; then
                uci set firewall.@zone[$zi].masq='1' 2>/dev/null || true
                uci set firewall.@zone[$zi].mtu_fix='1' 2>/dev/null || true
                FW_DIRTY=1
            fi
        fi
    done
    if [ "$FW_DIRTY" -eq 1 ]; then
        uci commit firewall >/dev/null 2>&1 || true
        /etc/init.d/firewall reload >/dev/null 2>&1 || true
    fi

    # Ensure policy routing table and rule exist (using table 100 for guaranteed kernel lookup)
    if ! grep -q "100[[:space:]]\+mmo_proxy" /etc/iproute2/rt_tables 2>/dev/null; then
        mkdir -p /etc/iproute2
        echo "100 mmo_proxy" >> /etc/iproute2/rt_tables
    fi
    if ! ip rule show | grep -qE "0x100/0xff00 lookup (mmo_proxy|100)"; then
        ip rule add fwmark 0x100/0xff00 lookup 100 2>/dev/null || ip rule add fwmark 0x100/0xff00 lookup mmo_proxy 2>/dev/null || true
    fi
    ip route replace local default dev lo table 100 2>/dev/null || ip route replace local default dev lo table mmo_proxy 2>/dev/null || true

    # Only restart sing-box if config actually changed or process is not running!
    if [ "$NEED_RESTART_SB" -eq 1 ] || ! pidof sing-box >/dev/null 2>&1; then
        echo "[*] Restarting mmo-proxy service (config changed)..."
        /etc/init.d/mmo-proxy restart
    else
        echo "[OK] Sing-box config unchanged. Service kept running smoothly."
    fi

    # Flush conntrack sessions ONLY for mapped proxy devices (NEVER flush Direct WAN devices to prevent dropping active SSH/IDE streams)
    if [ -n "$MAPPED_IPS" ]; then
        for fip in $MAPPED_IPS; do
            # Ensure we do not flush any IP that is in DIRECT_IPS
            if echo "$DIRECT_IPS" | grep -qw "$fip"; then
                continue
            fi
            conntrack -D -s "$fip" >/dev/null 2>&1 || true
            conntrack -D -d "$fip" >/dev/null 2>&1 || true
        done
    fi

    rm -f "$LOCK_FILE"
    echo "[OK] System applied successfully!"
}

rollback() {
    echo "[*] Rolling back mmo_proxy..."
    nft delete table inet mmo_proxy 2>/dev/null || true
    ip rule del fwmark 0x100/0xff00 lookup mmo_proxy 2>/dev/null || true
    ip route flush table mmo_proxy 2>/dev/null || true
    /etc/init.d/mmo-proxy stop 2>/dev/null || true
    echo "[OK] Rollback complete. Normal traffic restored."
}

fast_assign() {
    MAC=$(echo "$1" | tr 'A-Z' 'a-z')
    IP="$2"
    HOST="$3"

    [ -z "$MAC" ] && return 0

    # Whitelist check (Admin PC)
    DIRECT_MACS=$(jq -r '.direct_wan_devices // [] | .[]' "$CONFIG_SETTINGS" 2>/dev/null | tr 'A-Z' 'a-z')
    for dmac in $DIRECT_MACS; do
        [ "$dmac" = "$MAC" ] && return 0
    done

    AUTO_ENABLE=$(jq -r '.auto_proxy.enable // false' "$CONFIG_SETTINGS" 2>/dev/null)
    [ "$AUTO_ENABLE" != "true" ] && return 0

    # Check if already assigned
    EXISTING_PROXY=$(jq -r --arg m "$MAC" '.mappings[]? | select((.mac | ascii_downcase) == $m) | .proxy // empty' "$CONFIG_MAPPINGS" 2>/dev/null)
    if [ -n "$EXISTING_PROXY" ] && [ "$EXISTING_PROXY" != "DIRECT" ]; then
        EXISTING_IP=$(jq -r --arg m "$MAC" '.mappings[]? | select((.mac | ascii_downcase) == $m) | .ip // empty' "$CONFIG_MAPPINGS" 2>/dev/null)
        if [ "$EXISTING_IP" != "$IP" ] && [ -n "$IP" ]; then
            jq --arg m "$MAC" --arg ip "$IP" '
              .mappings = [((.mappings // [])[]) | if (.mac | ascii_downcase) == $m then .ip = $ip else . end]
            ' "$CONFIG_MAPPINGS" > "$CONFIG_MAPPINGS.tmp" 2>/dev/null && mv "$CONFIG_MAPPINGS.tmp" "$CONFIG_MAPPINGS"
            conntrack -D -s "$IP" 2>/dev/null || true
            conntrack -D -d "$IP" 2>/dev/null || true
            apply
        fi
        return 0
    fi

    # Read available proxies
    AVAIL_PROXIES=$(jq -r '(.proxies // [])[] | select(.enabled != false) | .name' "$CONFIG_PROXIES" 2>/dev/null)
    [ -z "$AVAIL_PROXIES" ] && AVAIL_PROXIES=$(jq -r '.auto_proxy.proxy_list // [] | .[]' "$CONFIG_SETTINGS" 2>/dev/null)
    [ -z "$AVAIL_PROXIES" ] && return 0

    # Round-robin allocation
    MAPPED_COUNT=$(jq '.mappings // [] | length' "$CONFIG_MAPPINGS" 2>/dev/null || echo 0)
    TOTAL_P=$(echo "$AVAIL_PROXIES" | wc -l)
    [ "$TOTAL_P" -eq 0 ] && return 0
    PICK_IDX=$(( (MAPPED_COUNT % TOTAL_P) + 1 ))
    RAW_PICK=$(echo "$AVAIL_PROXIES" | sed -n "${PICK_IDX}p")

    if echo "$RAW_PICK" | grep -q '://' || echo "$RAW_PICK" | grep -q ':'; then
        PICKED_P=$(jq -r --arg p "$RAW_PICK" --argjson idx "$PICK_IDX" '
          def parse_proxy(raw; idx):
            (raw | ltrimstr("socks5://") | ltrimstr("socks://") | ltrimstr("http://") | ltrimstr("https://")) as $clean |
            (if (raw | startswith("http://") or startswith("https://")) then "http" else "socks5" end) as $proto |
            (if ($clean | contains("@")) then
              ($clean | split("@")) as $at_parts |
              ($at_parts[0] | split(":")) as $auth_parts |
              ($at_parts[1] | split(":")) as $host_parts |
              {
                type: $proto,
                host: $host_parts[0],
                port: ($host_parts[1] | split("/")[0] | try tonumber catch 1080),
                user: ($auth_parts[0] // ""),
                pass: ($auth_parts[1:] | join(":"))
              }
            else
              ($clean | split(":")) as $parts |
              {
                type: $proto,
                host: $parts[0],
                port: ($parts[1] | split("/")[0] | try tonumber catch 1080),
                user: ($parts[2] // ""),
                pass: ($parts[3:] | join(":"))
              }
            end) as $p |
            $p + {
              name: ("Auto_" + ($p.host | split(".")[0]) + "_" + ($p.port | tostring) + "_" + ($idx | tostring)),
              enabled: true
            };
          parse_proxy($p; $idx).name
        ' "$CONFIG_SETTINGS" 2>/dev/null)
    else
        PICKED_P="$RAW_PICK"
    fi
    [ -z "$PICKED_P" ] && return 0

    DEV_NAME="$HOST"
    [ -z "$DEV_NAME" ] || [ "$DEV_NAME" = "*" ] && DEV_NAME="Device_$(echo "$MAC" | tr -d ':' | tail -c 5)"

    echo "[*] Fast-Assign: Cấp tức thì proxy $PICKED_P cho thiết bị mới $MAC ($IP)..."
    jq --arg m "$MAC" --arg ip "$IP" --arg n "$DEV_NAME" --arg p "$PICKED_P" '
      .mappings = [((.mappings // [])[]) | select((.mac | ascii_downcase) != $m)] + [{mac: $m, ip: $ip, name: $n, proxy: $p}]
    ' "$CONFIG_MAPPINGS" > "$CONFIG_MAPPINGS.tmp" 2>/dev/null && mv "$CONFIG_MAPPINGS.tmp" "$CONFIG_MAPPINGS"

    # Immediately flush conntrack to kill any lingering connections
    conntrack -D -s "$IP" 2>/dev/null || true
    conntrack -D -d "$IP" 2>/dev/null || true

    apply
}

on_dhcp() {
    fast_assign "$@"
}

on_offline() {
    MAC=$(echo "$1" | tr 'A-Z' 'a-z')
    [ -z "$MAC" ] && return 0

    # Do not delete mapping on temporary disconnect - only flush conntrack
    _ip=$(jq -r --arg m "$MAC" '.mappings[]? | select((.mac | ascii_downcase) == $m) | .ip // empty' "$CONFIG_MAPPINGS" 2>/dev/null)
    if [ -n "$_ip" ]; then
        conntrack -D -s "$_ip" 2>/dev/null || true
        conntrack -D -d "$_ip" 2>/dev/null || true
    fi
}

case "$1" in
    gen-singbox) generate_singbox ;;
    gen-firewall) generate_firewall ;;
    apply) apply ;;
    check-auto) shift; check_auto_proxy "$@" ;;
    fast-assign) shift; fast_assign "$@" ;;
    on-dhcp) shift; on_dhcp "$@" ;;
    on-offline) shift; on_offline "$@" ;;
    rollback) rollback ;;
    *) echo "Usage: $0 {apply|rollback|check-auto|fast-assign|on-dhcp|on-offline|gen-singbox|gen-firewall}" ;;
esac
